let app = getApp();
let that;

Page({
    data: {
        //评分
        stars: [0, 0, 0, 0, 0],
        star_nosrc: 'http://cdn.xsmore.com/Images/Applet/star_cur1.png',
        star_cursrc: 'http://cdn.xsmore.com/Images/Applet/star_no1.png',
        key: 0.5,

        imghost: app.imghost,
        evaluateData: [], //评论
        prodata_hide: true,
        complete_hide: true,
        TotalNum: 0,
    },

    //加载
    onLoad(option) {
        that = this;

        that.ProductId = option.ProductId || '';
        
        that.GetEvaluate();
    },

    GetEvaluate(changed = {}) {
        if(!that.ProductId) that.setData({prodata_hide:false});

        app.showLoading('页面加载中');

        return app._request('commentList',{ ProductId: that.ProductId},data => {
            app.hideLoading();

            let result = data.Result || {};
            //console.log(result);

            if(result.Results && result.Results.length) {

                changed['evaluateData'] = result.Results;
                changed['complete_hide'] = false;
                changed['prodata_hide'] = true;
            }else {
                changed['prodata_hide'] = false;
                changed['complete_hide'] = true;
            };

            if(result.Total) changed['TotalNum'] = result.Total;
            
            return that.setData(changed);
        });
    },

})
