// 订单状态
// public enum EnumOrderState {
//   未付款 = 1,
//   待审核 = 2,
//   待发货 = 3,
//   已发货 = 4,
//   已完成 = 5,
//   申请取消 = 6,
//   已取消 = 8,
//   待成团 = 9,
//   订单关闭 = 10
// }

let that
const app = getApp()

Page({
  data: {
    showorderbutton: true,
    pagedata:null,
    imghost: app.imghost,
    shopPrice:null,
    OrderNo:null,
    ColonelInfo:null,
  },
  init(){
    let requedata = {
      OrderNo: that.data.OrderNo
    };
    return app._request('orderdetail', requedata, data => {
      let result = data.Result
      console.log(result)
      that.setData({
        pagedata: result
      });
      if (result.Order.OrderState == 3 || result.Order.OrderState == 4 || result.Order.OrderState == 5){
          that.setData({
            showorderbutton:true,
          });
      }else{
        that.setData({
          showorderbutton: false,
        });
      }

      that.calc();
      app.hideLoading();

    });
  },
  gopay(){
    let requedata_two = {
      OrderNo: that.data.OrderNo,
      M: true
    };
    app._request('getwxjsapiparam', requedata_two, data => {
      console.log(data);
      app._payment(data.Result, data => {
        app._showToast('支付成功', "success");
        app._navto(2, '/pages/settlement/orderdetail?OrderNo=' + requedata_two.OrderNo);
      }, () => {
        app._navto(2, '/pages/settlement/orderdetail?OrderNo=' + requedata_two.OrderNo);
      });

    });
  },
  searchlog(e){
    
    app._navto(1, '/pages/logistics/logistics?id=' + e.currentTarget.dataset.no);
  },
  calc(){
    let zong = 0;
    let sum = that.data.pagedata.OrderDetails;
    for (var i = 0; i < sum.length ; i++){
      zong += sum[i].ProductPrice * sum[i].ProductCount
    }
    
    that.setData({
      shopPrice:zong
    })
  },
  onLoad:function(options) {
    that = this
    that.setData({
      OrderNo: options.OrderNo
    })
    
  },
  onShow(){
    that.init()
    wx.setNavigationBarTitle({
      title: "订单详情",
    })
  },

  tel: function () {

    let phone = this.data.pagedata.ColonelPhone;
    if (phone) {
      wx.makePhoneCall({
        phoneNumber: phone,
      })
    }

  },
  goindex(e) {
    app._navto(4, '/pages/shoplist/shoplist');
  },

  

})