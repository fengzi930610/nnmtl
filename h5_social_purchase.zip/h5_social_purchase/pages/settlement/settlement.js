let that
const app = getApp()
import Toast from '../../dist/toast/toast';

Page({
  data:{
    
    pagedata:null,
    imghost: app.imghost,
    price:null,
    realname:'',
    realphone:'',
    desc:'',
    show:false,
    areashow:true,
    guige:null,  //规格id
    Comunity:null
  },
  init() {
    console.log(that.data.pagedata);

    // inputname(e){
    //   that.setData({
    //     realname: e.detail.value
    //   })
    // },
    // inputphone(e) {
    //   that.setData({
    //     realphone: e.detail.value
    //   })
    // },
    // inputdesc(e) {
    //   that.setData({
    //     desc: e.detail.value
    //   })
    // },
    that.setData({
      realname: that.data.pagedata.CustomerInfo.Name,
      realphone: that.data.pagedata.CustomerInfo.WxPhone,
    })
  },
  calc(){
    let sum = that.data.pagedata.OrderDetails
    let zong = 0;
    for(var i=0;i<sum.length;i++){
      zong += sum[i].ProductPrice * sum[i].ProductCount
    }
     that.setData({
       price: zong.toFixed(2),
     })
  },
  gocalc(){
    if (that.data.realname == '' || that.data.realphone == ''){
      Toast({
        duration: '1000',
        message: '请填写好预留信息'
      });
      return false;
    }
    that.setData({
      show:true,
      areashow:false
    })
  },
  cancelcalc() {
    that.setData({
      show: false,
      areashow: true
    })
  },
  getnum(){
    that.setData({
      show:false
    })
    let requedata = {
      SpecId: that.data.guige,
      Num: that.data.pagedata.OrderDetails[0].ProductCount,
      CommunityId: that.data.Comunity,
      ReservedName: that.data.realname,
      ReservedPhone: that.data.realphone,
      ReservedRemark: that.data.desc
    };
    console.log( requedata);
    app._request('getordernum', requedata, data => {
      app.showLoading();
     // console.log(data.Result.OrderNo)
      let requedata_two = {
        OrderNo: data.Result.OrderNo,
        M: true
      };
      app._request('getwxjsapiparam', requedata_two, data => {
      //  app.hideLoading();
        console.log(data);
      app._payment(data.Result, data => {
        // console.log("请求结果")
        // console.log(data);
          app._showToast('支付成功', "success");
          app._navto(2, '/pages/settlement/orderdetail?OrderNo=' + requedata_two.OrderNo);
        }, () => {
          console.log(data)
          app._navto(2, '/pages/settlement/orderdetail?OrderNo=' + requedata_two.OrderNo);
        });

      });

    });
  },
  inputname(e){
    that.setData({
      realname : e.detail.value
    })
  },
  inputphone(e) {
    that.setData({
      realphone: e.detail.value
    })
  },
  inputdesc(e) {
    that.setData({
      desc : e.detail.value
    })
  },
  onLoad(options){
    that=this
    that.setData({
      guige: options.id,
      pagedata: JSON.parse(wx.getStorageSync('data')), // 上一页传来的数据
      Comunity: wx.getStorageSync('CommunityId')
    });
  },
  onShow(){
    that.init();
    that.calc();
  }
})