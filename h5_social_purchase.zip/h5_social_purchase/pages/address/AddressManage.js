let app = getApp();
let that;

Page({
    data: {
        apidata: [],
        complete_hide: true
    },
    onShow() {
        that = this;

        return that.GetList();
    },

    GetList(changed = {}){
        //app.showLoading('加载中');
        return app._request('myaddress', {} ,data => {
            let result = data.Result || {};
            //app.hideLoading();

            if(result.Addresses && result.Addresses.length){
                changed['apidata']  = result.Addresses;
            }else{
                changed['complete_hide']  = false;
            };
            
            return that.setData(changed);
        });
    },
    //单选按钮 设置默认
    radiobtnfn(event) {
        let apidata = that.data.apidata,
            index = event.currentTarget.dataset.index,
            seldata = apidata[index];

        if (!seldata.IsDefault) {
            app.showLoading("");
            /*apidata.map(function(el, ix) {
                el.IsDefault = (ix == index) ? true : false;
            });*/
            return app._request('setdefault',{ Id:seldata.Id },data => {
                app.hideLoading();
                return that.GetList();
            });
        };
    },
    delbtnfn(event) {
        let apidata = that.data.apidata,
            index = event.currentTarget.dataset.index,
            seldata = apidata[index];

        return app._showModalTip('确定要删除此收货地址吗？',(res)=>{

            if (!seldata.IsDefault) {
                app.showLoading("");
                return app._request('addrdelete',{ Id:seldata.Id },data => {
                    app.hideLoading();
                    return that.GetList();
                });
            }else{
                return app._showModalTip('默认地址不可删除');
            };
        },true);
    },

    //修改地址
    comsbtnfn(event) {
        let apidata = that.data.apidata,
            index = event.currentTarget.dataset.index,
            seldata = apidata[index];

        return app._navto(1,'AddressAdd?seldata=' + JSON.stringify(seldata));
    }
})
