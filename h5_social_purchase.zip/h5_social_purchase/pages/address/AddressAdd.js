let app = getApp();
let that;

Page({
    data: {
        seldata: {},

        //地址
        region:[],
        region_txt: '',
        init_region: [], //初始地址
        pickstate: false,
        addr_show: false,
    },
    onLoad(options) {
        that = this;

        if (options.seldata) {
            let seldata = JSON.parse(options.seldata);
            let region = (seldata.Province) ? [seldata.Province,seldata.City,seldata.Area]: [];
            //console.log(init_region);
            that.Id = seldata.Id;
            return that.setData({
                seldata,
                region,
                init_region: region,
                region_txt: region.join(''),
                addr_show: true
            });
        }else{
            return that.setData({
                addr_show: true
            });
        };
    },
    //地址
    address_show() {
        return that.setData({
            pickstate: true
        });
    },
    pick_cancel() {
        return that.setData({
            pickstate: false
        });
    },
    //确认按钮
    picker_confirm(event) {
        let region = event.detail.region;
        let pickstate = event.detail.pickstate;

        return that.setData({
            pickstate,
            region,
            region_txt: region.join('')
        });
    },

    //提交
    bindFormSubmit(event) {
        let requedata = event.detail.value;
        let region = that.data.region;

        if(that.Id) requedata['Id'] = that.Id;
        

        if (requedata.Name == '') {
            return app._showToast('收货人不能为空','none');

        } else if (!(/0?(13|14|15|18)[0-9]{9}$/.test(requedata.Phone))) {
            return app._showToast('请填写正确的手机号','none');

        } else if (region.length!=3) {
            return app._showToast('所在地区不能为空','none');

        } else if (!requedata.Address) {
            return app._showToast('请填写详细地址','none');

        } else {

            requedata['Province'] = region[0];
            requedata['City'] = region[1];
            requedata['Area'] = region[2];

            let tiptxt = (that.Id) ? '编辑' : '添加';
            app.showLoading(tiptxt+'中');
            //提交地址
            return app._request('addrupdate',requedata,data => {
                app.hideLoading();
                app._showToast(tiptxt+'成功','none');
                app._navto(5);
            });
        };
    },

})
