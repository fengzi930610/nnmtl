var app = getApp();
Page({
  data:{
    apidata:[]
  },
  onShow:function(options){
    var that = this,url=app.loghost+"customer/myaddress",requedata = {};
    that.requestfn(url,requedata);
  },
  //请求接口
  requestfn:function(url,requedata){
    var that = this;
    app.requestfn(url,requedata,function(res){
      that.sucessfn(res.data);
    });
  },
  sucessfn:function(data){
    var that = this;
    that.setData({
      apidata:data.Addresses
    })
  },
  listclick:function(event){
    var that = this,
      addrs = {},
      addrdata = that.data.apidata;
    addrs.addrdata = addrdata;
    addrs.addrindex = event.currentTarget.dataset.index;
    wx.setStorage({
      key:"addrs",
      data:addrs,
      success:function(res){
        wx.navigateBack({
          delta: 1
        });
      }
    });
  }
})