let app = getApp()
let that;
let pageSize, pageIndex, isLoadedOnce, isLoaded;

Page({
    data: {
        OrderEntity: {},
        ExpressList: [],

        imghost: app.imghost
    },
    onLoad(option) {
        that = this;

        that.OrderNo = option.OrderNo;

        that.GetExpressOrderInfo()
    },

    GetExpressOrderInfo() {
        app.showLoading('页面加载中');
        return app._request('order_express',{ OrderNo: that.OrderNo },data => {
            app.hideLoading();

            let result = data.Result[0] || [];
            console.log(result);
            return that.setData({
                OrderEntity: result,
                ExpressList: result.TraceList || [],
            });
        });
    },

})
