let that;
let app = getApp();

Page({
    data: {
        apidata: [], //产品信息
        imghost: app.imghost,
        buynum: 0, //数量

        addrdata: [], //地址信息
        addrindex: 0,

        Coupons_txt: '',
        Coupons: [], //优惠券列表
        OrderMoney: 0, //订单金额
    },
    onLoad(option) {
        //console.log('abnor',option);
        that = this;

        that.SpecId = option.SpecId; //规格id
        that.GActivityId = option.GActivityId; //活动id
        that.GroupBuyId = option.GroupBuyId || ""; //参团id || 不传开团

        that.isfirst = true;

        that.ProductMoney = 0; //商品价格
        that.PostageMoney = 0; //运费

        that._init();
    },
    onUnload() {
        app.session.clear('confirm');
    },

    onShow() {
        if (that.isfirst) return false;

        let addrdata = that.data.addrdata;
        //if (!addrdata.length) return false;

        let curobj = addrdata[that.data.addrindex] || {};

        return that._getAddress(datas => {
            let data = datas[that.data.addrindex] || {};
            //console.log(curobj,data);
            if (data.Province == curobj.Province && data.City == curobj.City && data.Area == curobj.Area) return false;
            //console.log(data,curobj,datas);
            app.showLoading('加载中');

            let confirm = app.session.get('confirm');

            confirm.Addresses = datas;
            app.session.set('confirm', confirm);

            return that._getpostmoney(data.Province, {
                addrdata: datas
            });

        });
    },

    //获取地址
    _getAddress(callback) {
        return app._request('myaddress', {}, data => {
            let result = data.Result || {};
            let addrdata = [];

            if (result.Addresses && result.Addresses.length) addrdata = result.Addresses;

            return callback && callback(addrdata);
        });
    },

    //运费计算
    _getpostmoney(Province, changed = {}) {
        let requedata = {
            Province: Province,
            SpecId: that.SpecId,
            Num: that.data.buynum
        };

        return app._request('getpostmoney', requedata, data => {
            let result = data.Result || {};

            app.hideLoading();
            that.PostageMoney = result.Money || 0;

            changed['OrderMoney'] = app._float(that.ProductMoney + that.PostageMoney, 2);
            console.log('getpostmoney', that.PostageMoney);

            return that.setData(changed);
        });
    },

    _init(changed = {}) {
        let result = app.session.get('confirm');

        if (!result) return app._navto(2, app.default_path);
        console.log(result);

        if (result.Addresses && result.Addresses.length > 0) changed['addrdata'] = result.Addresses;
        if (result.OrderDetails && result.OrderDetails.length > 0) {
            changed['apidata'] = result.OrderDetails;
            changed['buynum'] = result.OrderDetails[0].ProductCount || 0;
        };
        if (result.Coupons && result.Coupons.length > 0) {
            changed['Coupons'] = result.Coupons.filter((el, ix) => {
                return el.Usable;
            });
            if (changed['Coupons'].length) changed['Coupons_txt'] = changed['Coupons'].length + '张';
        };
        if (result.OrderMoney) changed['OrderMoney'] = result.OrderMoney;

        that.ProductMoney = result.ProductMoney || 0;
        that.PostageMoney = result.PostageMoney || 0;

        return that.setData(changed, () => {
            that.isfirst = false;
        });
    },

    GetList(changed = {}) {

    },

    //提交订单
    submit_click() {
        app.showLoading('提交中');
        return that._submit();
    },
    _submit() {
        if (!that.data.addrdata.length) return app._showToast('请选择地址');

        let requedata = {
            SpecId: that.SpecId,
            Num: that.data.buynum,
            AddressId: that.data.addrdata[that.data.addrindex].Id,
            GActivityId: that.GActivityId
        };

        if (that.CouponId) requedata.CouponId = that.CouponId; //优惠券
        if (that.GroupBuyId) requedata.GroupBuyId = that.GroupBuyId; //参团

        return app._request('submit', requedata, data => {
            let result = data.Result || {};

            that.OrderNo = result.OrderNo || '';
            that.Free = result.Free; //是否免支付

            app.session.set('OrderNo', that.OrderNo);

            console.log(that.OrderNo);
            app.showLoading('支付中');
            if (!that.Free) return that._pays();
            else return app._navto(2, '/pages/group/group-result?GroupBuyId='+that.GroupBuyId+'&OrderNo='+that.OrderNo);
        });
    },

    //支付
    _pays() {
        let requedata = {
            OrderNo: that.OrderNo,
            M: true
        };

        return app._request('getwxjsapiparam', requedata, data => {
            app.hideLoading();
            return app._payment(data.Result || {}, () => {
                app._showToast('支付成功', "success");
                setTimeout(() => {
                    app._navto(2, '/pages/group/group-result?GroupBuyId='+that.GroupBuyId+'&OrderNo='+that.OrderNo);
                });
            }, () => {
                app._showToast('支付失败', "none");
            });
        });
    },

    //优惠券
    coupon_click() {
        if(!that.data.Coupons_txt) return false;
        
        let Coupons = that.data.Coupons;
        let itemList = Coupons.map((el, ix) => {
            return el.Limit;
        });
        itemList.unshift('不使用');

        return wx.showActionSheet({
            itemList,
            success(res) {
                    let changed = {};

                    if (res.tapIndex) {
                        let curs = Coupons[res.tapIndex - 1];
                        console.log(curs);

                        that.CouponId = curs.Id || '';
                        changed['OrderMoney'] = app._float(that.ProductMoney + that.PostageMoney - curs.RealMoney, 2);
                        changed['Coupons_txt'] = '-￥' + curs.RealMoney;
                        //console.log(that.ProductMoney,that.PostageMoney);
                    } else {
                        that.CouponId = '';
                        changed['OrderMoney'] = app._float(that.ProductMoney + that.PostageMoney, 2);
                        if (Coupons.length) changed['Coupons_txt'] = Coupons.length + '张';
                    };

                    return that.setData(changed);
                },
                fail(err) {
                    //console.log(err.errMsg)
                }
        })
    }

})
