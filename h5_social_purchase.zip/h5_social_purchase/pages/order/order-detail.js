let app = getApp();
let that;

Page({
    data: {
        order: {},
        details:[],
        discount: 0, //总优惠金额
        orderStateList:app.orderStateList,
        imghost: app.imghost,
        IsUseFreight: true,
        FreightDetail: 'sdf',
        OrderRecordList: []
    },

    onLoad(option) {
        that = this;

        that.OrderNo = option.OrderNo;
        wx.hideShareMenu();

        return that.GetDetail();
    },

    GetDetail(){
        app.showLoading();

        return app._request('orderdetail',{OrderNo:that.OrderNo},data => {
            wx.hideLoading();

            let result = data.Result || {};
            let order = result.Order || {};
            let ActivityCouponMoney = order.ActivityCouponMoney || 0;
            let TogetherMoney = order.TogetherMoney || 0;
            let discount = app._float(TogetherMoney + ActivityCouponMoney,2);
            
            return that.setData({
                discount,
                order,
                details: result.OrderDetails || [],
            });
        });
    },

    onShareAppMessage(res){
        let title = app.share_title;
        let index = res.target.dataset.index;
        let curdata = that.data.order;
        //console.log('onShareAppMessage',curdata);
        let path = '/pages/group/joinGroup?GroupBuyId='+curdata.GroupBuyId;
        let img = app.imghost + that.data.details[0].ImgUrl;
        if (res.from === 'button') return app._shareObj(title,path,img);
    },

    //复制按钮
    copy_click(){
        let OrderNo = that.data.order.OrderNo;

        return app._ciipData(OrderNo,()=>{
            return app._showToast('复制成功!');
        });
    },

    /*底部按钮*/

    //确认收货
    confirm_receipt(event) {
        let OrderNo = event.currentTarget.dataset.no;

        return app._showModalTip('您确认收到货了吗?',()=>{

            return app._request('order_complete',{ OrderNo: OrderNo },data => {
                console.log(data);
            });
        },true);
        
    },

    //返回拼团详情
    goto_group(event){
        let OrderNo = event.currentTarget.dataset.no;

        return app._navto(1,'/pages/group/group-detail?OrderNo='+OrderNo);
    },

    //再来一团
    group_again(event){
        let ActivityId = that.data.order.ActivityGroupBuyingId;
        let ProductId = that.data.details[0].ProductId;

        return app._navto(2,'/pages/product/product-detail?ActivityId='+ActivityId+'&ProductId='+ProductId);
    },

    //去支付按钮
    go_pay(event){
        app.showLoading('支付中');

        let OrderNo = event.currentTarget.dataset.no || '';
        let requedata = {
            OrderNo: OrderNo,
            M:true
        };
        
        let curdata = that.data.order;
        let GroupBuyId = curdata.GroupBuyId || '';
        
        return app._request('getwxjsapiparam',requedata,data => {
            app.hideLoading();
            return app._payment(data.Result || {},()=>{
                app._showToast('支付成功',"success");
                setTimeout(()=>{
                    app._navto(2,'/pages/group/group-result?GroupBuyId='+GroupBuyId+'&OrderNo='+OrderNo);
                });
            },()=>{
                app._showToast('支付失败',"none");
            });
        });
    },

    //查看物流
    goto_express(event){
        let OrderNo = event.currentTarget.dataset.no;

        return app._navto(1,'/pages/order/order-express?OrderNo='+OrderNo);
    },

    goto_home(){
        return app._navto(3,'/pages/home/home');
    }

})
