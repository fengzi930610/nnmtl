let that;
let app = getApp();

Page({
    data: {
        apidata:[],
        CategoryId:0,
        imghost:app.imghost,
        GroupBuyCoverUrl:'',

        complete_hide:true,
        isfoot_show:true,
        navlist: [],
        nav_cur: 0,
    },
    onLoad(option) {
        //console.log('abnor',option);
        that = this;

        app.showLoading('页面加载中');

        that.GetList();
    },
    _init(info){
        that.isfirst = false;
        
    },
    onShareAppMessage(res){
        let title = '优质好货，快来和我一起拼~';
        let img = 'https://cdn.xiaojiankeji.com/images/Applet/cjyp_buy/cjyp-share-pic.jpg';
        return app._shareObj(title,'',img);
    },

    GetList(changed = {}){
        let requedata = {
            CategoryId: changed.CategoryId ? changed.CategoryId : '',
            Skip:0,
            Take:100
        };

        if(that.productlist) that.productlist.abort();
        that.productlist = app._request('productlist',requedata,data => {
            let Result = data.Result || {};
            let navlist = Result.Categories || [];
            let Products = Result.Products || {};
            
            app.hideLoading();
            if(navlist.length) changed['navlist'] = navlist;
            if(Result.GroupBuyCoverUrl) changed['GroupBuyCoverUrl'] = Result.GroupBuyCoverUrl;
            changed['apidata'] = Products.Results || [];
            changed['complete_hide'] = false;
            
            return that.setData(changed);
        });
    },

    navli_click(event){
        let index = event.currentTarget.dataset.index;
        let curlist = that.data.navlist[index];
        let changed = {
            nav_cur: index,
            CategoryId: curlist.Id
        };

        app.showLoading('切换中',false);
        
        return that.GetList(changed);
    },

    nato_detail(event){
        let index = event.currentTarget.dataset.index;
        let curList = that.data.apidata[index];

        return app._navto(1,'/pages/product/product-detail?' + ['ActivityId='+curList.GroupBuyingId,'ProductId='+curList.Id].join('&'));
    }
})
