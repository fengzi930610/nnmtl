let that
const app = getApp()
var p=0;
Page({
  data: {
    scrollLeft: 0, //tab标题的滚动条位置
    menuList: [{
      name: "全部",
      state:0
    }, {
        name: "待付款",
        state: 1
    }, {
        name: "待发货",
        state: 2
    }, {
        name: "已发货",
        state: 4
    },{
        name: "已完成",
        state: 20
    }],
    
    currentTab:0,
    orderstate:0,
    imghost: app.imghost
    
  },
  clickMenu: function (e) {
    let state = e.currentTarget.dataset.state //获取当前状态
    let index = e.currentTarget.dataset.cur //获取当前tab的index
    if (that.data.currentTab == index) {
      return false
    } else {
      that.setData({
         currentTab: index,
         orderstate: state
       })
      that.init()
      that.checkCor()
    }
  },
  //判断当前滚动超过一屏时，设置tab标题滚动条。
  checkCor: function () {
    if (that.data.currentTab > 4) {
      that.setData({
        scrollLeft: 300
      })
    } else {
      that.setData({
        scrollLeft: 0
      })
    }
  },
  init(){
    p = 0;
    console.log("开始请求数据")

    let requedata = {
      OrderStateParam: that.data.orderstate,
      Take: 10,
      Skip: p * 10,
    };
    console.log(requedata);
    return app._request('myorder', requedata, data => {
      let result = data.Result.Results;
      // console.log(data.Result);
      if (result.length > 0) {
      that.setData({
        pagedata: result,
        showModal: false,
      })
      }else{
        that.setData({
          pagedata: "",
          showModal: true,
        })
      }
      app.hideLoading();
      wx.stopPullDownRefresh();
    });

  },
  requestData(){
    let requedata = {
      OrderStateParam: that.data.orderstate,
      Take: 10,
      Skip: p * 10,
    };
    console.log(requedata);
    return app._request('myorder', requedata, data => {
      let result = data.Result.Results;
      // console.log(data.Result);
      console.log(1111);
      if (result.length > 0) {
        if (p > 0) {
          that.setData({
            pagedata: that.data.pagedata.concat(result),
            showModal: false,
          })
        } else {
          that.setData({
            pagedata: result,
            showModal: false,
          })
        }
        p++;
      }else{
        console.log("没有更多数据");
        console.log(p);
        if (p < 0) {
          that.setData({
            showModal: true,
          })
        }
      }
      
        
      app.hideLoading();
      wx.stopPullDownRefresh();
    });
  },
  select_list(e){
    
    console.log(e.currentTarget.dataset.no)
    return app._navto(1, '/pages/settlement/orderdetail?OrderNo=' + e.currentTarget.dataset.no);
  },
  onLoad () {
    that =this
    
  },
  onShow() {
    p = 0;
    that.init();
    wx.setNavigationBarTitle({
      title: '我的订单',
    })
  },

  onPullDownRefresh: function () {
    //下拉
    console.log("下拉");
    p = 0;
    console.log(p);
    that.requestData();
    // that.setData({
    //   apidata: [],
    // });



  },
  onReachBottom: function () {
    //上拉
    console.log("上拉");
    that.requestData();
    // console.log(p);
  }
})