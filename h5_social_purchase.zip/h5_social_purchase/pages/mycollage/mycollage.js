let app = getApp()
let that;

Page({
    data: {
        apidata: [],
        BrandName: null,
        IsUseFreight: null,

        orderStateList: app.orderStateList,
        imghost: app.imghost,
        prodata_hide: true,
        complete_hide: true,
        isPopup: false,

        GroupBuyState: ['未成团','组团中','已成团','组团失败'],
        isfoot_show:true,
        navcur:0,
        navlist:[
            {txt:'全部',state:''},
            {txt:'拼团中',state:'[9]'},
            {txt:'待付款',state:'[1]'},
            {txt:'待发货',state:'[2,3]'},
            {txt:'待收货',state:'[4]'},
        ],
    },
    onLoad() {
        that = this;

        that.state = "";
        app.showLoading('页面加载中');
        wx.hideShareMenu();

        return that.GetOrder();
    },
    _showModal(content,callback,tit){
        return wx.showModal({
            title        : tit || '提示',
            content      : content,
            confirmColor : '#ed7d7d',
            confirmText  : '确认',
            showCancel   : true,
            complete(res) {
                if(res.confirm){
                    return callback && callback();
                }
            }
        });
    },
    onShareAppMessage(res){
        let title = app.share_title;
        let index = res.target.dataset.index;
        let curdata = that.data.apidata[index];
        
        console.log('onShareAppMessage',curdata);
        let path = '/pages/group/joinGroup?GroupBuyId='+curdata.GroupBuyId;
        let img = app.imghost + curdata.Details[0].ImgUrl;
        if (res.from === 'button') return app._shareObj(title,path,img);
    },

    GetOrder(changed = {},callback) {
        let requedata = {
            OrderTypeIn: '[3]',
            OrderStateIn: that.state
        };
        
        if(that.myorder) that.myorder.abort();
        that.myorder = app._request('myorder',requedata,data => {
            app.hideLoading();

            let result = data.Result || {};

            changed['apidata'] = result.Results || [];

            if(changed['apidata'].length) {
                changed['prodata_hide'] = true;
                changed['complete_hide'] = false;
            } else {
                changed['prodata_hide'] = false;
                changed['complete_hide'] = true;
            };

            return that.setData(changed,callback);
        });
    },

    //菜单切换
    navi_click(event) {
        console.log('菜单切换', event.detail.item);
        that.state = event.detail.item.state;

        app.showLoading('切换中',false);
        return that.GetOrder();
    },

    //确认收货
    confirm_receipt(event) {
        let OrderNo = event.currentTarget.dataset.no;

        return app._showModalTip('您确认收到货了吗?',()=>{

            return app._request('order_complete',{ OrderNo: OrderNo },data => {
                app._showToast('收货成功');
                return that.GetOrder();
            });
        },true);
        
    },

    //返回拼团详情
    goto_group(event){
        let OrderNo = event.currentTarget.dataset.no;

        return app._navto(1,'/pages/group/group-detail?OrderNo='+OrderNo);
    },

    //再来一团
    group_again(event){
        let index = event.currentTarget.dataset.index;
        let curList = that.data.apidata[index];

        let ActivityId = curList.GroupBuy.ActivityId;
        let ProductId = curList.Details[0].ProductId;

        return app._navto(2,'/pages/product/product-detail?ActivityId='+ActivityId+'&ProductId='+ProductId);
    },

    //去支付按钮
    go_pay(event){
        app.showLoading('支付中');

        let OrderNo = event.currentTarget.dataset.no || '';
        let requedata = {
            OrderNo: OrderNo,
            M:true
        };
        
        let index = event.currentTarget.dataset.index;
        let curdata = that.data.apidata[index];
        let GroupBuyId = curdata.GroupBuyId || '';

        return app._request('getwxjsapiparam',requedata,data => {
            app.hideLoading();
            return app._payment(data.Result || {},()=>{
                app._showToast('支付成功',"success");
                setTimeout(()=>{
                    app._navto(2,'/pages/group/group-result?GroupBuyId='+GroupBuyId+'&OrderNo='+OrderNo);
                });
            },()=>{
                app._showToast('支付失败',"none");
            });
        });
    },

    //查看物流
    goto_express(event){
        let OrderNo = event.currentTarget.dataset.no;

        return app._navto(1,'/pages/order/order-express?OrderNo='+OrderNo);
    }, 

    //取消订单
    cancel_order(event){
        let OrderNo = event.currentTarget.dataset.no;
        let Reason = '';

        const callfn = ()=>{
            let requedata = {
                OrderNo,
                Reason
            };
            
            return app._request('order_cancel',requedata,data => {
                app._showToast('取消成功');
                
                return that.GetOrder({},()=>{
                    return app._navto(1,'/pages/order/order-detail?OrderNo='+OrderNo);
                });
            });
        };

        return wx.showActionSheet({
            itemList: app.cancelList,
            success(res) {
                Reason = app.cancelList[res.tapIndex];
                //app._showToast(app.cancelList[res.tapIndex]);
                return that._showModal('取消原因：' + Reason,callfn,'取消订单');
            },
            fail(res) {

            }
        });
        
        
    },

    goto_order(event){
        let OrderNo = event.currentTarget.dataset.no;

        return app._navto(1,'/pages/order/order-detail?OrderNo='+OrderNo);
    },
    go_group(event){
        let GroupBuyId = event.currentTarget.dataset.id;

        return app._navto(2,'/pages/group/joinGroup?GroupBuyId='+GroupBuyId);
    },

})
