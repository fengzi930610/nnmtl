let that
const app = getApp()
Page({
  data: {
  },
  init() {
    wx.chooseLocation({

    })
  },
  onLoad() {
    that = this
  },
  onShow() {
    that.init()
  }
})