let app = getApp();

let zsSuit = require('../../utils/ZsSuit.js');
let specMark = '/' //规格分隔符

Page({
    data: {
        result:{},
        imghost:app.imghost,
        port_imgs:[],
        port_max: app.port_max,
        
        countDownList:[],

        /*规格*/
        specData:{},
        buynum: 1,
        specState: false,
    },
    onLoad(option) {
        //console.log('abnor',option);
        that = this;

        that.GroupBuyId = option.GroupBuyId || 0;
        that.GActivityId = '';
        that.curSpecId = '';

        that.actCount1 = new app._actCountDown();

        zsSuit.callBack = (nodata, skuId) => {
            //console.log('callBack',nodata, skuId, that.Specs, that.curSpecId);
            let specData = that.data.specData;
            let price = specData.price;
            let imgurl = specData.imgurl;

            that.curSpecId = skuId;
            //console.log(skuId);
            if (skuId) {
                price = that.Specs[skuId].GroupBuyPrice;
                if(that.Specs[skuId].ImgUrl) imgurl = app.imghost + that.Specs[skuId].ImgUrl;
            };

            specData.price = price;
            specData.imgurl = imgurl;

            specData.alldata.forEach((el, ix) => {
                el.data.forEach((el1, ix1) => {
                    if (nodata[ix].indexOf(ix1 + 1 + '') !== -1) {
                        el1.disable = true
                    } else {
                        el1.disable = false
                    };
                });
            });
            //console.log('specData',specData);
            return that.setData({
                specData: specData
            });
        };

        return that.GetDetail();
    },
    onUnload(){
        that.actCount1._clear();
    },
    //头像更多按钮
    port_more_click(){
        return that.setData({
            port_max: that.data.port_imgs.length
        });
    },
    _init(info){
        if(that.data.result.Ends) return that.actCount1._run([that.data.result.Ends], (arr,state) => {
            //console.log('_actCountDown',app._actJoin(arr),state);
            return that.setData({
                countDownList: app._actJoin(arr)
            });
        },1);
        //that.GetDetail();
    },
    onShareAppMessage(res){
        let title = app.share_title;
        let path = '/pages/group/joinGroup?GroupBuyId='+that.GroupBuyId;
        let img = app.imghost + that.data.result.ProductImgUrl;

        return app._shareObj(title,path,img);
    },
    GetDetail(changed = {}){
        let requedata = {
            GroupBuyId: that.GroupBuyId,
        };

        app.showLoading('页面加载中');
        return app._request('joinGroup',requedata,data => {
            let result = data.Result || {};

            app.hideLoading();
            let specData = that.getSpec(result);

            that.GActivityId = result.GroupBuyingId || '';

            let port_imgs = [];
            let HeadUrls = result.HeadUrls || [];

            if(result.GroupCount>1){
                for (let i = 1; i < result.GroupCount; i++) {
                    port_imgs.push(HeadUrls[i] || 'https://cdn.xiaojiankeji.com/images/Applet/cjyp_buy/group-pic1.jpg');
                };
            };
            
            //console.log(result,port_imgs);
            return that.setData({
                result,
                port_imgs,
                specData
            },that._init);
        });
    },

    group_join(){
        if(that.data.result.CanJoin && that.data.result.Remain){
            return that.spec_show();
        }else{
            if(!that.data.result.CanJoin){
                return app._showModalTip('这个商品仅限新用户参团，您是老用户，可以去开团!');
            }else if(!that.data.result.Remain){
                 return app._showModalTip('这个商品人数已满');
            }else{
                return app._showModalTip('这个商品不能参团');
            };
        };
    },

    /*规格 - 购物车*/
    buynextfn() {
        let buynum = that.data.buynum+1;

        return that.check_buynum(buynum);
    },
    buyprevfn() {
        let buynum = that.data.buynum-1;

        if(buynum>0) return that.check_buynum(buynum);
        else app._showToast('不可再减','none');
        
    },
    buytxtblur(event) {
        return that.check_buynum(event.detail.value);
    },
    check_buynum(buynum,callback){
        if(that.curSpecId){
            let changed = {};
            let stock = that.Specs[that.curSpecId].RealStock || 0;

            if(buynum > stock) {
                that.setData({
                    buynum:1
                });
                return app._showToast('库存不足','none');
                //buynum = 1;
            } else if(buynum == "") buynum = 1;

            changed['buynum'] = buynum;
            return that.setData(changed,callback);

        }else return app._showToast('请选择规格','none');
    },

    //确认请求 开团
    nowbuyfn(){
        let buynum = that.data.buynum;

        if(that.once_pay) return app._showToast('不能重复点击');

        return that.check_buynum(buynum,()=>{
            let requedata = {
                SpecId: that.curSpecId,
                Num: buynum,
                GActivityId: that.GActivityId
            };

            if(that.GroupBuyId) requedata.GroupBuyId = that.GroupBuyId;
            that.once_pay = true;

            return app._request('confirm',requedata,data => {
                let result = data.Result || {}
                //console.log(data);

                that.once_pay = false;
                app.session.set('confirm',result);

                return app._navto(1,'/pages/order/order-confirm?' + ['SpecId='+that.curSpecId,'GActivityId='+that.GActivityId,'GroupBuyId='+that.GroupBuyId].join('&'));
            },()=>{
                that.once_pay = false;
            });
        });
    },

    /*规格*/

    //规格隐藏
    specloose() {
        return that.setData({
            specState: false
        });
    },
    spec_show(){
        return that.setData({
            specState: true
        });
    },

    //规格按钮选择
    specasli_click(event) {
        let curarr = event.currentTarget.dataset.curtxt.split(","),
            index = parseInt(curarr[0], 10),
            idx = parseInt(curarr[1], 10);
        let specData = that.data.specData;
        let curData = specData.alldata[index];
        let curVal = curData.data[idx];
        let chooseFlag = (idx === curData.actnum - 1); //是否选中状态

        if (curVal.disable) return false;

        if (chooseFlag) {
            curData.actnum = 0;
            zsSuit.unset(index, idx + 1);
        } else {
            curData.actnum = idx + 1;
            zsSuit.set(index, idx + 1);
            //console.log(index, idx + 1);
        };

        //console.log(specData);
        specData.toppl = that.getSpecToppl();

        return that.setData({
            specData: specData
        });
    },

    getSpec(Product){
        let specData = {};

        specData.imgurl = app.imghost + Product.ProductImgUrl //头像
        specData.price = Product.GroupBuyPrice || 0 //价格

        let alldata = that.initSpecData(Product.Specs, Product.SpecTitle, Product.SpecTitle2);
        specData.alldata = alldata;

        let tips = '';
        if (alldata.length == 0) {
            tips = '没有规格';
        } else if (Product.Specs.length == 1) {
            zsSuit.paramsSort = [1,1];

            that.curSpecId = Product.Specs[0].Id;
            tips = '已选规格：' + Product.Specs[0].SpecValue;
            if (Product.SpecTitle2) tips += specMark + Product.Specs[0].SpecValue2;
        };
        specData.toppl = that.getSpecToppl(tips);

        return specData;
    },
    //获取规格
    getSpecToppl(tips) {
        let toopl = '请选择';
        if (tips) {
            toopl = tips;
        } else if (that.curSpecId) { //已选择
            let curdata = that.Specs[that.curSpecId];

            toopl = '已选规格：' + curdata.SpecValue;
            if (curdata.SpecValue2 !== "") toopl += specMark + curdata.SpecValue2;
        };
        return toopl;
    },
    //获取规格all数据 || 不计算库存
    initSpecData(Specs, SpecTitle, SpecTitle2){
        let specData = [];

        if (SpecTitle) {
            let obj1 = {
                actnum: 0,
                title: SpecTitle,
                data: []
            };
            let obj2 = (SpecTitle2) ? {
                actnum: 0,
                title: SpecTitle2,
                data: []
            } : null;
            let tempObj1 = [],
                tempObj2 = [];
                //let suitRuleInfo = {}
            let suitRuleInfo1 = {};

            that.Specs = {};
            if (Specs.length === 1) {
                obj1.actnum = 1; //只有一个并库存足够
                if (obj2) obj2.actnum = 1;
            };

            Specs.forEach((el, ix) => {
                let obj = {
                    txt: el.SpecValue,
                    disable: false
                };
                let arr1 = [];
                let curi1 = app._findIndex(obj1.data, obj);
                    //console.log(curi1,el.SpecValue);
                that.Specs[el.Id] = el;
                if (curi1 == -1) {
                    obj1.data.push(obj);
                    arr1.push(obj1.data.length);
                } else {
                    arr1.push(curi1 + 1);
                };

                if (obj2) {
                    let objj = {
                        txt: el.SpecValue2,
                        disable: false
                    };
                    let curi2 = app._findIndex(obj2.data, objj);
                        //console.log(curi2,obj2.data,objj);

                    if (curi2 == -1) {
                        obj2.data.push(objj);
                        arr1.push(obj2.data.length);
                    } else {
                        arr1.push(curi2 + 1);
                    };
                };

                //suitRuleInfo[el.Id] = arr.join('_')
                suitRuleInfo1[el.Id] = arr1.join('_');
            });

            specData.push(obj1);
            if (obj2) { //大于1级时
                specData.push(obj2);
                //console.log(suitRuleInfo1);
            };

            zsSuit.num = specData.length;
            zsSuit.config({
                'suitRuleInfo': suitRuleInfo1
            });
        };

        return specData;
    },
})
