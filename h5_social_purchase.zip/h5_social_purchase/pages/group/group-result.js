let that;
let app = getApp();

Page({
    data: {
        result:{},
        imghost:app.imghost,
        port_imgs:[],
        port_max:app.port_max,
    },
    onLoad(option) {
        //console.log('abnor',option);
        that = this;

        that.GroupBuyId = '';
        that.GActivityId = '';
        that.OrderNo = option.OrderNo; // TD180803700348 || TD180803200487

        that.actCount1 = new app._actCountDown();
        wx.hideShareMenu();

        return that.GetDetail();
    },
    onUnload(){
        that.actCount1._clear();
    },
    onShareAppMessage(res){
        let title = '我正在参加拼团，一起拼更便宜！';
        let path = '/pages/group/joinGroup?GroupBuyId='+that.GroupBuyId;
        let img = app.imghost + that.data.result.ProductImgUrl;
        if (res.from === 'button') return app._shareObj(title,path,img);
    },

    _init(info){
        if(that.data.result.Ends && that.data.result.State == '拼团中') return that.actCount1._run([that.data.result.Ends], (arr,state) => {
            //console.log('_actCountDown',app._actJoin(arr),state);
            return that.setData({
                countDownList: app._actJoin(arr)
            });
        },1);
        //that.GetDetail();
    },
    //头像更多按钮
    port_more_click(){
        return that.setData({
            port_max: that.data.port_imgs.length
        });
    },
    GetDetail(changed = {}){
        let requedata = {
            OrderNo: that.OrderNo,
        };

        app.showLoading('页面加载中');
        return app._request('groupdetail',requedata,data => {
            let result = data.Result || {};

            app.hideLoading();

            let port_imgs = [];
            let HeadUrls = result.HeadUrls || [];

            if(result.GroupCount>1){
                for (let i = 1; i < result.GroupCount; i++) {
                    port_imgs.push(HeadUrls[i] || 'https://cdn.xiaojiankeji.com/images/Applet/cjyp_buy/group-pic1.jpg');
                };
            };

            that.GroupBuyId = result.GroupBuyId || '';

            if(result.IsLeader) wx.setNavigationBarTitle({
                title: '开团成功'
            });
            //console.log(result);
            return that.setData({
                IsLeader: result.IsLeader,
                result,
                port_imgs
            },that._init);
            
        });
    },

    goto_deatil(){
        return app._navto(2,'/pages/group/group-detail?OrderNo='+that.OrderNo);
    }
})
