let that;
let app = getApp();

Page({
    data: {
        imghost:app.imghost,
        apidata: [],
        total: 0,
        head_img: app.head_img,
        
        //活动结束时间
        countDownList: [],
        actEndTimeList: [],
    },
    onLoad(option) {
        //console.log('abnor',option);
        that = this;

        that.act_dd = new app._actCountDown();
        that.ActivityId = option.ActivityId || "";
        that.ProductId = option.ProductId || "";

        that._init();
    },

    onUnload(){
        that.act_dd._clear();
        //return app.session.clear('GroupBuys');
    },

    _countDown(){
        if(that.data.actEndTimeList.length) return that.act_dd._run(that.data.actEndTimeList, (arr,state) => {
            //console.log('_actCountDown',app._actJoin(arr),state);
            return that.setData({
                countDownList: app._actJoin(arr)
            });
        },1);
    },

    _init(info){
        let requedata = {
            ActivityId: that.ActivityId,
            ProductId: that.ProductId
        };

        app.showLoading('页面加载中');

        return app._request('grouplist', requedata, data => {
            let result = data.Result || {};
            let apidata = result.Results || [];
            let actEndTimeList = apidata.map((el,ix) => {
                return el.Ends;
            });
            let total = result.Total;

            app.hideLoading();
            return that.setData({
                apidata,
                actEndTimeList,
                total
            },that._countDown);
        });
    },

    GetList(changed = {}){
        
    },

    //一键参团
    goto_join(event){
        let id = event.currentTarget.dataset.id;

        return app._navto(1,'/pages/group/joinGroup?GroupBuyId='+id);
    }


})
