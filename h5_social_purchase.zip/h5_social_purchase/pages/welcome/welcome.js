let that;
let app = getApp();

let config = require('../../config');

Page({
    data: {
    },
    onLoad(option) {
        //console.log('abnor',option);
        that = this;
        that.isfirst = false;
        
    },
    _init(info){
        that.isfirst = false;
        app.hideLoading();
        console.log('info',info);

        let path = config.welcome_path || config.default_path;
        
        return app._navto(3,path);
    },
    //初始授权
    bindGetUserInfo(event) {
        //if(that.isfirst) return false;

      //  that.isfirst = true;

       if (event.detail.userInfo) {
            app.showLoading("授权中");
            return app.initAuthLogin(event.detail, that._init);
        }else return app._showModalTip('取消授权登录将无法进入页面，请授权');
      
    },
})
