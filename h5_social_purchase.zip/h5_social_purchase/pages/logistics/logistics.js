
let that
const app = getApp()

Page({
  data: {
    orderid:'',
    apidata:null
  },
  init(){
    let requedata = {
      OrderNo: that.data.orderid
    };

    app._request('myexpress', requedata, data => {
      console.log(data)
      that.setData({
        apidata: data.Result[0]
      })
    });

  },
  onLoad(options){
    that=this
    that.setData({
        orderid: options.id
      //orderid: 'TD181023300067'
    })
  },
  onShow(){
    that.init()
  }
})

