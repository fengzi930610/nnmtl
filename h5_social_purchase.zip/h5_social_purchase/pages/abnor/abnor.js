let that;
let app = getApp();

const config = require('../../config');
const taburls = config.taburls;
//const taburls = ['pages/AllList/AllList', 'pages/MyMember/MyMember', 'pages/Material/Materiallist'];

Page({
  data: {
    'request_error': {
      image: '/images/request_error.png',
      title: '网络加载失败',
      button: '点击刷新'
    },
    abnor_info: '',
    path: '',
    info_show: true,
  },
  onLoad(option) {
    //console.log('abnor',option);
    that = this;

    that.route = option.route;

    /*that.params = option
    delete that.params.route*/
    //console.log('params:',option.params,JSON.parse(option.params));

    let path = config.abnor_path || config.default_path;
    let changed = {};

    //if(option.params && option.params!='{}') path += app._paramsToString(JSON.parse(option.params));

    return wx.getStorage({
      key: 'abnor_info',
      success(res) {
        if (res.data) {
          changed = {
            abnor_info: res.data,
            path: path
          };

          if (option.title) changed['request_error.title'] = option.title;
          if (option.ishide) changed['info_show'] = false;

          return that.setData(changed);
        };
      },
      fail(err) {
        console.log(err);
      }
    });
  },
  emitAbnorTap() {

    if (that.route) {
      let navi = 2;
      let url = that.data.path;
      if (~taburls.indexOf(that.route)) navi = 3;
      var mpath = that.data.path;
      if (mpath.indexOf("shoplist") != -1 || mpath.indexOf("mine") != -1)
        navi = 4;
      return app._navto(navi, url);
    } else {
      return app._showModalTip('route无数据,刷新失败');
    }
  }
})