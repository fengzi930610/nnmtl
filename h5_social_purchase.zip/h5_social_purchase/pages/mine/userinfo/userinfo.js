const app = getApp();
import Toast from '../../../dist/toast/toast';
let that = this

Page({
  data: {
    userdata:null,
    Name:'',
    Phone:''
  },
  onLoad: function (options) {
    let data = JSON.parse(options.obj)
    console.log(data)
    this.setData({
      userdata:data,
      Phone: data.Phone ? data.Phone : '',
      Name: data.Name ? data.Name : ''
    });
  },
  onShow: function () {
    wx.setNavigationBarTitle({
      title: '个人信息'
    });
  },
  save: function () {
    let phone = this.data.Phone
    if (phone.length != 11 || phone.substring(0,1) !='1' || !phone ) {
      wx.showToast({
        title: '请输入手机号!',
        icon: 'loading',
        duration: 1500
      })
      return ;
    }
    let name = this.data.Name;
    let requedata = {
      RealName: this.data.Name,
      Phone: this.data.Phone
    };
    console.log(requedata);
    return app._request('updateuserinfo', requedata, data => {
      let resdata = data;
      console.log(data);
      if (data.ErrorCode ==0){//修改成功
        wx.showToast({
          title: '修改成功',
          icon: 'succes',
          duration: 1000,
          mask: true
        });
        setTimeout(function () {
          app._navto(5)
        }, 1000) //延迟时间 这里是1秒
      }else{
        wx.showToast({
          title: '修改失败',
          duration: 1000,
          mask: true
        });
      }
    });
  },

  inputphone: function (e) {
    let phone = e.detail.value;
    this.setData({
      Phone: phone,
    });
    console.log(phone);
  },

  inputname: function (e) {
    // console.log(e.detail.value);
    let name = e.detail.value;
    this.setData({
      Name: name,
    });
    console.log(name);
  }

})