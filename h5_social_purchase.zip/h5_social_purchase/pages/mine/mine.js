const app = getApp()
let that = this
Page({
  data: {
//
    userinfo: null,
    menuitems: [{
      text: '我的订单',
      icon: '../../images/mine/my_order.png',
      url: "../state/state",
      tips: ''
    },
    {
      text: '团长招募',
      icon: '../../images/mine/head_recruit.png',
      url: "../mine/recruit/recruit?phone=",
      tips: ''
    },
    {
      text: '团长信息',
      icon: '../../images/mine/head_info.png',
      url: "../mine/headinfo/headinfo",
      tips: ''
    },
      {
        text: '切换小区',
        icon: '../../images/mine/head_info.png',
        url: "../communitylist/communitylist",
        tips: ''
      },
    ],
    Business:null,
    imgUrl:''

  },
  
  onLoad() {
    that = this;
  },
  onShow: function () {
    that = this;
    that.setData({
      imgUrl: app.imghost,
    }); 
    this.requestdata()
    wx.setNavigationBarTitle({
      title: '个人中心'
    });
  },

  itemclickaction(e){

    app._navto(1, '/pages/mine/myinfo/myinfo?id=' + e.currentTarget.dataset.id);

  },

  pushview(e) {

    var dict = {
      "HeadUrl": that.data.userinfo.HeadUrl,
      "WxNickname": that.data.userinfo.WxNickname,
      "Phone": that.data.userinfo.Phone,
      "Name":that.data.userinfo.Name,
    };

    app._navto(1, '/pages/mine/userinfo/userinfo?obj=' + JSON.stringify(dict));
  },

  requestdata() {

    app._request('userinfo', '', date => {
      let result = date.Result;
      that.setData({
        userinfo: result,
      }); 
      if (result.IsColonel == true) { //是代理商则不把CommunityId写入本地
        console.log("团长》》》");
        if (result.CommunityId) {
          console.log(result.CommunityId);
          wx.setStorage({
            key: 'CommunityId',
            data: result.CommunityId
          });
          let send = {
            CommunityId:result.CommunityId
          }
          app._request('colonel', send, data => {
            let result = data.Result
            that.setData({
              Business: result
            })
          })
        };
      }else{
        console.log("不是代理商");
      }
      app.hideLoading();

    })
    
  },

})
