const app = getApp()
let that = this
Page({

  
  /**
   * 页面的初始数据
   */
  data: {
    dataArr:[],
    latitude: null, //维度
    longitude: null, //经度
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    that = this;
    this.requestdata();

    //获取经纬度

    wx.getLocation({
      type: 'gcj02', //返回可以用于wx.openLocation的经纬度
      success: function (res) {
        console.log(res),
        that.setData({
          latitude : res.latitude, //维度
          longitude : res.longitude //经度
        })
        
      }
    })

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

    if (that.data.latitude && that.data.longitude){
        // console.log(that.data.latitude, that.data.longitude)
      console.log(that.getDistance(that.data.latitude, that.data.longitude, 23.15809, 113.27209))


    }
    //getDistance
    

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },
  itemclickAction:function(e){

    // let communityId = this.data.dataArr[e.currentTarget.dataset.id].Id;
    // if(communityId){
    //   wx.setStorage({
    //     key: 'CommunityId',
    //     data: communityId
    //   });
    //   wx.getStorage({
    //     key: 'CommunityId',
    //     success: function(res) {
    //       console.log(res);
    //     },
    //     fail : function(e){
    //       console.log("e====="+e);
    //     }
    //   })
    //   wx.navigateBack({
        
    //   });
    // }
    //
    app._navto(1, '../communitylist/communitymap/communitymap');
  },

  requestdata() {

    return app._request('getCommentlist', '', date => {
      let result = date.Result.Results;
      let arr = [];
      for (var i = 0; i < result.length; i++) {
        arr.push(result[i]);
      }
      that.setData({
        dataArr: arr
      });
    })
  },

  getDistance: function (lat1, lng1, lat2, lng2) {
    lat1 = lat1 || 0;
    lng1 = lng1 || 0;
    lat2 = lat2 || 0;
    lng2 = lng2 || 0;

    var rad1 = lat1 * Math.PI / 180.0;
    var rad2 = lat2 * Math.PI / 180.0;
    var a = rad1 - rad2;
    var b = lng1 * Math.PI / 180.0 - lng2 * Math.PI / 180.0;
    var r = 6378137;
    var distance = r * 2 * Math.asin(Math.sqrt(Math.pow(Math.sin(a / 2), 2) + Math.cos(rad1) * Math.cos(rad2) * Math.pow(Math.sin(b / 2), 2)));

    return distance;
  },

})