let that
const app = getApp()
var p = 0;
Page({
  data: {
    searchinput: '',
    isShowClose:false,
    focus: false,
    apidata:[],
    imghost: app.imghost,
    Community:null,
    CommunityName:'',
    callphone:'',
    BusinessLogoUrl:null,
    mnumb:123.4345,
    show:true
  },

  clear_text(){
    console.log("清除")
    that.setData({
      isShowClose:false,
      show:true,
      searchinput:""
    })
  },
  onShareAppMessage() {

    var communityId = wx.getStorageSync('CommunityId')
    let title = that.data.CommunityName + '-' + that.data.apidata[0].ProductName;
    var path ;
    if (communityId){
      path = '/pages/shoplist/shoplist?CommunityId=' + communityId;
    }else{
      path = '/pages/shoplist/shoplist?' ;
    }
    // console.log(path);
    let img = app.imghost + that.data.apidata[0].ProductImgUrl;
    return app._shareObj(title, path, img);
    
  },
  checksearch(e) {
    //console.log(e);
    if (e.detail.value != '') {
      that.setData({
        show: false,
        isShowClose:true
      })
    } else {
      that.setData({
        show: true,
        isShowClose: false
      })
    }
  },
  searchshop (e) {
    var value = wx.getStorageSync('CommunityId')
    let requedata = {
      CommunityId: value,
      Keywords: e.detail.value
    };
    return app._request('productList', requedata, data => {
      app.showLoading('页面加载中');
      let result = data.Result.Products.Results;
      let arr = [];
      for (var i = 0; i < result.length; i++) {
        arr.push(result[i]);
      }
      
      that.setData({
        apidata: arr,
      });
      
      app.hideLoading();
    });
  },
 
  listdata() {
    let requedata = {
      CommunityId: that.data.Community,
      Take: 20,
      Skip: p * 20,
    };
    // console.log(requedata);
    app.showLoading('页面加载中');
    return app._request('productList', requedata, data => {

      let result = data.Result.Products.Results;
      console.log(data);
      if (result.length > 0) {
        var arr = [];
        if (p > 0) {
          arr = that.data.apidata;
        }
        p++;
        for (var i = 0; i < result.length; i++) {
          arr.push(result[i]);
        }
        that.setData({
          apidata: arr,
          CommunityName: data.Result.CommunityId ? data.Result.CommunityId : ''
        });
        // console.log(that.data.apidata);
      } else {
        console.log("没有数据++");
      }
      app.hideLoading();
    });
  },
  phonedata() {
    var value = wx.getStorageSync('CommunityId');
    if (value) {

      let requedata = {
        CommunityId: value
      };
      return app._request('GetApplyPhone', requedata, data => {
        let result = data.Result
        that.setData({
          callphone: result
        })
      });
    }
    
  },

  go_detail(e) {
    app._navto(1, '/pages/shopdetail/shopdetail?id=' + e.currentTarget.dataset.id );
  },
  joinin(e) {
    app._makePhoneCall(that.data.callphone)
  },
  push_CommunityList(e){
    app._navto(1, '/pages/communitylist/communitylist');
  },
  onLoad(options) {
    that = this;
    console.log(options);
    var communityId = options.CommunityId;
    if (communityId){
      wx.setStorage({
        key: 'CommunityId',
        data: communityId
      });
    };
    
  },
  inputfocus(){
    console.log("获取焦点");
    this.setData({
      focus: true
    });
  },
  onShow () {
    this.requestcommunitymessage();

    if (this.CommunityId) {
      p = 0;
      console.log("从分享也进来");
      this.listdata();
      this.phonedata();

    }else{
      
      try {
        var value = wx.getStorageSync('CommunityId');
        // console.log("value"+value+"本地小区"+that.data.Community);
        if ((that.data.Community && value != that.data.Community) || !that.data.Community ) {//判断是否切换了小区
          p = 0;
        }
        if (value) {//已经保存有社区Id的。
  
          that.setData({
            Community: value
          })
          this.listdata()
          this.phonedata()
        } else {// 没有社区id 去选择社区Id
          // this.push_CommunityList();
        }
      } catch (e) {
        // Do something when catch error
        // this.push_CommunityList();
      }

    }
  },

  changecommunity(){
    // this.push_CommunityList();
  },

  requestcommunitymessage(){
    var value = wx.getStorageSync('CommunityId');
    if (value) {
      var dict = {
        CommunityId: value ,
      };
      app._request('headinfo', dict, data => {
        let title = data.Result.BusinessName+" · " + data.Result.CommunityName;
        console.log("==========="),
          that.setData({ 
            BusinessLogoUrl: data.Result.BusinessLogoUrl,
            }),
          // console.log(that.data.BusinessLogoUrl),
        wx.setNavigationBarTitle({
          title: title,
        })
      });
    }

  },

  onPullDownRefresh: function () {
    //下拉
    // console.log("下拉");
    p = 0;
    this.listdata();
    wx.stopPullDownRefresh();

  },
  onReachBottom: function () {
    //上拉
    // console.log("上拉");
    this.listdata();
  }
  
})




