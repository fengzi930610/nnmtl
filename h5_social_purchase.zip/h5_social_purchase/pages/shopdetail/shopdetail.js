let that;
let WxParse = require('../../wxParse/wxParse.js')
import Toast from '../../dist/toast/toast';
const app = getApp()

Page({
  data: {
    color: "#02d792",
    purchase: "去结算",
    optid: '',
    pagedata: null,
    show: false,
    imghost: app.imghost,
    oreno: '',
    Community: null,
    huodong: null,
    shopmax: '',
    shopvalue: 1,
    isact: '',
    datetimer: "",
    swindex: 1
  },

  init() {
    let requedata = {
      id: that.data.optid,
      CommunityId: that.data.Community
    };
    return app._request('productDetail', requedata, data => {
      let result = data.Result.Product
      
      if (result.Specs[0].RealStock < 1) {
        that.setData({
          purchase: "已售馨",
          color: "#cccccc"
        })
      }
      if (result.Specs.length===1){//如果只有一个规格
        that.setData({
          huodong: result.Specs[0].SpikeId,
          shopvalue: 1,
          shopmax: result.Specs[0].RealStock,
          isact: result.Specs[0].Id,
          
        })
      }

      console.log(result)
      that.setData({
        pagedata: result,
        datetimer: result.EndTime.replace(/-/g, '.')
      })
      WxParse.wxParse('richData1', 'html', result.Detail, that);
      app.hideLoading();
    });
  },
  goindex(e) {
    // app._navto(5);
    // console.log("1");
    app._navto(4, '/pages/shoplist/shoplist');
  },
  gocalc() {
    if (that.data.purchase === "已售馨") {
      Toast({
        duration: '1000',
        message: '此商品已售馨'
      });
    } else {
      that.setData({
        show: true
      });
    }
  },
  numchange(e) {
    that.setData({
      shopvalue: e.detail
    })

  },

  numover(e) {
    if (that.data.shopvalue == 1) {
      app._showToast('不能再少了哦~');
    } else if (that.data.shopvalue <= that.data.shopmax) {
      app._showToast('不能再多了哦~');
    }

  },

  sure(e) {
    // console.log(e)
    //let huodong = e.currentTarget.dataset.huodong
    console.log(that.data.CommunityId);
    if (that.data.isact == '') {
      Toast({
        duration: '2000',
        message: '请选择商品规格'
      });
      return false;
    }
    let requedata = {
      SpecId: that.data.isact,
      SpikeId: that.data.huodong,
      CommunityId: that.data.Community,
      Num: that.data.shopvalue
    };
    console.log(requedata);
    return app._request('orderConfirm', requedata, data => {
      let result = data
      //  console.log(result)
      if (result.Result) {
        var json_data = JSON.stringify(result.Result);
        // console.log(aa)
        wx.setStorage({
          key: 'data',
          data: json_data
        })

        app._navto(1, '/pages/settlement/settlement?id=' + that.data.isact);
      }

    });
  },

  testnum(e) {
    that.setData({
      oreno: e.detail.value
    })
  },
  shopselect(e) {
    if(e.currentTarget.dataset.max == 0) {
      return false;
    }
    if (that.data.isact == e.currentTarget.dataset.id) {
      console.log(that.data.isact)
      that.setData({
        isact: ''
      })
    } else {
      that.setData({
        shopvalue: 1,
        shopmax: e.currentTarget.dataset.max,
        isact: e.currentTarget.dataset.id,
        huodong: e.currentTarget.dataset.huodong
      })
    }
  },
  onClose(e) {
    console.log(e)
    that.setData({
      show: false
    });

    /*console.log(that.data.oreno)
    let requedata = {
      OrderNo: that.data.oreno,
      M: true
    };

    return app._request('getwxjsapiparam', requedata, data => {
      app.hideLoading();
      console.log(data)
      return app._payment(data.Result || {}, () => {
        app._showToast('支付成功', "success");

      }, () => {

      });
    });*/

  },
  mswievent: function(event) {
    that.setData({
      swindex: event.detail.current + 1
    })
  },
  onShow: function() {
    //console.log(that.data.optid)
    that.init()
  },
  onShareAppMessage() {

    let communityId = wx.getStorageSync('CommunityId');
    let title = that.data.pagedata.CommunityName + '-' + that.data.pagedata.Name;
    let pruductId = that.data.pagedata.Id;
    var path;
    var dict;
    if (communityId) {
      dict = {
        "CommunityId": communityId,
        "productId": that.data.pagedata.Id,
      };

    } else {
      dict = {
        "productId": that.data.pagedata.Id,
      };
    }
    path = '/pages/shopdetail/shopdetail?dict=' + JSON.stringify(dict);
    let img = app.imghost + that.data.pagedata.ImgUrls[0];
    console.log(path);
    return app._shareObj(title, path, img);
  },
  onLoad: function(options) {
    that = this;
    let id;
    if (options.dict) {
      let dict = JSON.parse(options.dict);
      if (dict) {
        console.log("通过分享进来的" + dict);
        let communityId = dict.CommunityId;
        let productId = dict.productId;
        if (communityId) {
          wx.setStorage({
            key: 'CommunityId',
            data: communityId
          });
        };
        if (productId) {
          that.setData({
            optid: productId,
          })
        }
      };
    }
    let coutid = wx.getStorageSync('CommunityId');
    if (coutid) {
      id = coutid
    } else {
      app._navto(2, 'pages/shoplist/shoplist');
    }
    if (options.id) {
      that.setData({
        optid: options.id,
      })
    };
    if (id) {
      that.setData({
        Community: id
      })
    }
    app.showLoading('页面加载中');

    console.log("countId===" + coutid + "Community-----" + that.data.Community + "optionId" + that.data.optid);
  },
  closepup(){
    that.setData({
      show:false
    })
  }

})