"use strict"; !
function i(u, a, s) {
  function c(n, e) {
    if (!a[n]) {
      if (!u[n]) {
        var t = "function" == typeof require && require;
        if (!e && t) return t(n, !0);
        if (l) return l(n, !0);
        var r = new Error("Cannot find module '" + n + "'");
        throw r.code = "MODULE_NOT_FOUND",
        r
      }
      var o = a[n] = {
        exports: {}
      };
      u[n][0].call(o.exports,
      function(e) {
        return c(u[n][1][e] || e)
      },
      o, o.exports, i, u, a, s)
    }
    return a[n].exports
  }
  for (var l = "function" == typeof require && require,
  e = 0; e < s.length; e++) c(s[e]);
  return c
} ({
  1 : [function(e, n, t) {
    e("./wxjs/API");
    var r = e("./utils/index"),
    o = e("./config"),
    i = e("./wxjs/index"),
    u = r._paramsToString,
    a = r._compareVersion,
    s = r._actCountDown,
    c = r._actJoin,
    l = r._float,
    f = r._findIndex,
    d = (i.showLoading, i.hideLoading, i._showModalTip),
    g = i.initAuthLogin,
    p = (i.session, {
      sysInfo: null,
      userInfo: null,
      StoreId: null,
      userName: "",
      memberId: "",
      sceneId: 0,
      isVersion: !0,
      _paramsToString: u,
      _actCountDown: s,
      _actJoin: c,
      _findIndex: f,
      _float: l,
      initAuthLogin: function() {
        var n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
        t = arguments[1],
        e = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
        r = function(e) {
          return g(e,
          function(e) {
            return e.result || e.Result ? t && t(n.userInfo) : e ? t && t(e) : t && t()
          })
        };
        return e ? that.getStoreId(function(e) {
          return r({
            MallId: e
          })
        }) : r(n)
      },
      getSystemInfo: function(n) {
        var t = this;
        return t.sysInfo ? n && n(t.sysInfo) : wx.getSystemInfo({
          success: function(e) {
            return t.sysInfo = e,
            -1 === a(e.SDKVersion, "1.9.0") || -1 === a(e.version, "6.6.0") ? (t.isVersion = !1, t._lowtips()) : n && n(e)
          }
        })
      },
      _lowtips: function() {
        return d("当前微信版本过低，部分新功能无法使用，请升级到最新微信版本后重试。")
      },
      onLaunch: function(e) {
        this.sceneId = e.scene || this.sceneId
      },
      onShow: function(e) {
        return this.sceneId = e.scene || this.sceneId,
        this.getSystemInfo()
      },
      GetStoreId: function(t) {
        var r = this;
        return wx.getExtConfig ? wx.getExtConfig({
          success: function(e) {
            var n = e.extConfig;
            return n.StoreId = 2151,
            console.log("魔1.0.0", n),
            n.StoreId ? (r.StoreId = n.StoreId, t && t(r.StoreId)) : d("120-未获取到授权店铺,请联系客服")
          },
          fail: function(e) {
            return d("获取授权店铺失败,请联系客服")
          }
        }) : d("微信版本过低,无法获取模板信息,请更新版本")
      }
    });
    p = Object.assign(i, o, p),
    App(p)
  },
  {
    "./config": 2,
    "./utils/index": 5,
    "./wxjs/API": 7,
    "./wxjs/index": 11
  }],
  2 : [function(e, n, t) {
    var r = {
      appId: "wx43123493d7bae872",
      appSecret: "8cbfa3d093d391947a38e0ad9f3c7918",
      appName: "初家友品拼团购",
      imgcut_640: "@!cut640",
      imgcut_320: "@!cut320",
      welcome_path: "",
      abnor_path: "",
      default_path: "/pages/shoplist/shoplist",
      cancelList: ["收货人信息有误", "商品数量或款式需调整", "我不想买了", "一直未发货", "商品缺货", "其他原因"],
      share_title: "我正在参加拼团，一起拼更便宜！",
      head_img: "http://cdn.xsmore.com/Images/zmkm/pro_det_14.png",
      port_max: 9,
      // apihost: "https://spconsumerapi.chujiayoupin.com",
     apihost:'https://cjypwapapi.ynbyweishang.com',
      imghost: "https://img.xsmore.com/cjyp",
      cdnhost: "https://cdn.xiaojiankeji.com",
      upimg_url: "https://file.xsmore.com/api/image/upload?PlatForm=chujia&Path=Member",
      address_url: "https://cdn.xiaojiankeji.com/JSON/other/AreaData_overseas.json",
      StoreName: "初家友品-拼团活动",
      taburls: ["pages/welcome/welcome", "pages/mycollage/mycollage", "pages/home/home"],
      orderStateList: ["", "待付款", "待发货", "待发货", "待收货", "已完成", "申请取消", "", "已取消", "拼团中"]
    };
    n.exports = r
  },
  {}],
  3 : [function(e, n, t) {
    var p = function(e) {
      return (e = e.toString())[1] ? e: "0" + e
    };
    n.exports = {
      getAllTime: function(e) {
        var n = {
          year: e.getFullYear(),
          month: e.getMonth() + 1,
          day: e.getDate(),
          hour: e.getHours(),
          minute: e.getMinutes(),
          second: e.getSeconds()
        };
        for (var t in n) n[t] = p(n[t]);
        return n
      },
      formatDate: function(e, n) {
        var t = {
          "M+": e.getMonth() + 1,
          "d+": e.getDate(),
          "h+": e.getHours(),
          "m+": e.getMinutes(),
          "s+": e.getSeconds(),
          "q+": Math.floor((e.getMonth() + 3) / 3),
          S: e.getMilliseconds()
        };
        for (var r in /(y+)/.test(n) && (n = n.replace(RegExp.$1, (e.getFullYear() + "").substr(4 - RegExp.$1.length))), t) new RegExp("(" + r + ")").test(n) && (n = n.replace(RegExp.$1, 1 === RegExp.$1.length ? t[r] : ("00" + t[r]).substr(("" + t[r]).length)));
        return n
      },
      _actCountDown: function() {
        var t = {
          timebox: null,
          _run: function() {
            var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : [],
            n = arguments[1],
            f = arguments[2],
            d = [],
            g = e.length;
            if (e.forEach(function(e, n) {
              var t = void 0,
              r = void 0;
              if (1 == f) r = e;
              else {
                var o = (new Date).getTime(); (t = new Date(e).getTime()) || (t = Date.parse(e.replace(/-/g, "/"))),
                r = t - o
              }
              var i = {};
              if (0 < r) {
                var u = r / 1e3,
                a = parseInt(u / 86400),
                s = parseInt(u % 86400 / 3600),
                c = parseInt(u % 86400 % 3600 / 60),
                l = parseInt(u % 86400 % 3600 % 60);
                i = {
                  day: a,
                  hou: p(s),
                  min: p(c),
                  sec: p(l)
                }
              } else i = {
                day: "0",
                hou: "00",
                min: "00",
                sec: "00"
              },
              g--;
              d.push(i)
            }), !(0 < g)) return n && n(d, !0);
            n && n(d),
            t.timebox = setTimeout(function() {
              return 1 == f && (e = e.map(function(e, n) {
                return e - 1e3
              })),
              t._run(e, n, f)
            },
            1e3)
          },
          _clear: function() {
            clearTimeout(t.timebox)
          }
        };
        return t
      },
      _actJoin: function(e) {
        if (e.length) return e.map(function(e, n) {
          return e.day + "天 " + [e.hou, e.min, e.sec].join(":")
        })
      }
    }
  },
  {}],
  4 : [function(e, n, t) {
    n.exports = {
      isString: function(e) {
        return "string" == typeof e || e instanceof String
      },
      isFunction: function(e) {
        return e && "[object Function]" === {}.toString.call(e)
      },
      isArray: function(e) {
        return e.constructor === Array
      },
      isUndefined: function(e) {
        return void 0 === e
      },
      isCharacter: function(e) {
        return /^[\u4e00-\u9fa5]{0,}$/.test(e)
      },
      isNumber: function(e) {
        return null != e && 0 != e.length && (e.length < 2 ? /^[0-9]{0,}$/.test(e) : /^[1-9]{1}[0-9]{0,}$/.test(e))
      },
      _float: function(e, n) {
        var t = Math.pow(10, n);
        return Math.round(e * t) / t
      },
      getMaximin: function(e, n) {
        return "max" == e ? Math.max.apply(null, n) : "min" == e ? Math.min.apply(null, n) : void 0
      },
      _compareVersion: function(e, n) {
        e = e.split("."),
        n = n.split(".");
        for (var t = Math.max(e.length, n.length); e.length < t;) e.push("0");
        for (; n.length < t;) n.push("0");
        for (var r = 0; r < t; r++) {
          var o = parseInt(e[r]),
          i = parseInt(n[r]);
          if (i < o) return 1;
          if (o < i) return - 1
        }
        return 0
      },
      _trim: function(e, n) {
        var t = e.replace(/(^\s+)|(\s+$)/g, "");
        return n && (t = t.replace(/\s/g, "")),
        t
      },
      _keyid: function() {
        return Number(Math.random().toString().substr(3, 8) + Date.now()).toString(36)
      },
      stdExtName: function(e) {
        return e.replace(/[_-]||\s/g, "").toLowerCase()
      }
    }
  },
  {}],
  5 : [function(e, n, t) {
    var r = e("./helper"),
    o = e("./params"),
    i = e("./dates"),
    u = {
      _findIndex: function(e, t) {
        var r = -1;
        return e.map(function(e, n) {
          JSON.stringify(e) === JSON.stringify(t) && (r = n)
        }),
        r
      }
    };
    u = Object.assign(o, r, i, u),
    n.exports = u
  },
  {
    "./dates": 3,
    "./helper": 4,
    "./params": 6
  }],
  6 : [function(e, n, t) {
    n.exports = {
      _paramsToString: function(e) {
        var n = "",
        t = 0;
        for (var r in e) n += 1 == ++t ? "?" + r + "=" + e[r] : "&" + r + "=" + e[r];
        return n
      },
      getparams: function(e) {
        var n = {},
        t = e.match(/([^\?]+)/g);
        if (! (1 < t.length)) return n;
        for (var r = (t = t[1].split("&")).length, o = 0, i = void 0; o < r; o++) t[o] && (n[(i = t[o].split("="))[0]] = i[1]);
        return n
      }
    }
  },
  {}],
  7 : [function(e, n, t) {
    n.exports = {
      login: "auth",
      getToken: "session-to-token",
      productlist: "groupbuy/productlist",
      grouplist: "groupbuy/list",
      productdetail: "groupbuy/productdetail",
      favorite: "favorite",
      getwxjsapiparam: "payment/getwxjsapiparam",
      confirm: "order/confirm",
      submit: "order/submit",
      addrdelete: "customeraddress/delete",
      myaddress: "customeraddress/myaddress",
      setdefault: "customeraddress/setdefault",
      addrupdate: "customeraddress/update",
      getpostmoney: "freight/getpostmoney",
      commentList: "productcomment/list",
      joinGroup: "groupbuy/join",
      groupdetail: "groupbuy/detail",
      joinresult: "groupbuy/joinresult",
      myorder: "myorder",
      orderdetail: "customerorder/detail",
      order_complete: "myorder/complete",
      order_express: "myorder/express",
      order_cancel: "myorder/cancel",
      productList: "social/productList",
      GetApplyPhone:"social/GetApplyPhone",
      productDetail:"social/productDetail",
      orderConfirm:"order/confirm",
      userinfo: "member/getinfo",
      headinfo: "social/colonel",
      applyinfo: "social/getApplyPhone",
      getordernum:"order/submit",
      orderdetail:"myorder/detail",
      colonel:"social/colonel",
      myorder:"myorder",
      myexpress:"myorder/express",
      updateuserinfo: "member/updateinfo",
      getCommentlist: "social/getCommentList",
    }
  },
  {}],
  8 : [function(e, n, t) {
    var r = e("./_loading").hideLoading;
    n.exports = function() {
      var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "接口出错",
      n = arguments[1],
      t = 2 < arguments.length && void 0 !== arguments[2] && arguments[2];
      return r(),
      wx.showModal({
        title: "提示",
        content: e,
        showCancel: t,
        complete: function(e) {
          if (e.confirm) return n && n(e)
        }
      })
    }
  },
  {
    "./_loading": 10
  }],
  9 : [function(e, n, t) {
    n.exports = function() {
      var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
      n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "";
      return e && e.errMsg && (n = e.errMsg),
      n
    }
  },
  {}],
  10 : [function(e, n, t) {
    n.exports = {
      showLoading: function() {
        var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "加载中",
        n = !(1 < arguments.length && void 0 !== arguments[1]) || arguments[1];
        return wx.showLoading ? wx.showLoading({
          title: e,
          mask: n
        }) : wx.showToast({
          title: e,
          icon: "loading",
          duration: 3e4,
          mask: n
        })
      },
      hideLoading: function() {
        return wx.showLoading ? wx.hideLoading() : wx.hideToast()
      }
    }
  },
  {}],
  11 : [function(e, n, t) {
    var r, o = e("./login"),
    i = e("./_ModalTip"),
    u = e("./_errMsg"),
    c = e("../config"),
    a = e("./_loading"),
    l = a.showLoading,
    f = a.hideLoading,
    s = a._request,
    d = o.auth_Fail,
    g = function(e) {
      var n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "none",
      t = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 1500,
      r = !(3 < arguments.length && void 0 !== arguments[3]) || arguments[3];
      return wx.showToast({
        title: e,
        icon: n,
        duration: t,
        mask: r
      })
    },
    p = function(e, n) {
      return wx.showModal({
        title: "提示",
        content: e,
        confirmColor: "#4d8ac9",
        confirmText: "继续",
        cancelText: "不用",
        showCancel: !0,
        complete: function(e) {
          return n && n(e)
        }
      })
    },
    h = function n(t, r) {
      return wx.saveImageToPhotosAlbum({
        filePath: t,
        success: function(e) {
          return r && r(e)
        },
        fail: function(e) {
          return e && ~e.errMsg.indexOf("fail auth deny") ? d("writePhotosAlbum",
          function(e) {
            return e ? n(t, r) : r && r()
          }) : r && r()
        }
      })
    },
    m = function n(t, r) {
      return wx.saveVideoToPhotosAlbum({
        filePath: t,
        success: function(e) {
          return r && r(e)
        },
        fail: function(e) {
          return e && ~e.errMsg.indexOf("fail auth deny") ? d("writePhotosAlbum",
          function(e) {
            return e ? n(t, r) : r && r()
          }) : r && r()
        }
      })
    };
    r = Object.assign({
      _showModalTip: i,
      _showToast: g,
      _navto: function(e, n) {
        return 1 === e ? wx.navigateTo({
          url: n
        }) : 2 === e ? wx.redirectTo({
          url: n
        }) : 3 === e ? wx.reLaunch({
          url: n
        }) : 4 === e ? wx.switchTab({
          url: n
        }) : 5 === e ? wx.navigateBack({
          delta: n || 1
        }) : void 0
      },
      _shareObj: function() {
        var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "",
        n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "",
        t = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : "",
        r = arguments[3];
        return {
          title: e,
          path: n,
          imageUrl: t || "",
          success: function(e) {
            return g("分享成功", "success"),
            r && r()
          },
          fail: function(e) {
            return g("分享已取消", "success")
          }
        }
      },
      showLoading: l,
      hideLoading: f,
      _uploadImage: function(s) {
        return function(n) {
          var e = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1;
          return wx.chooseImage({
            count: e,
            success: function(e) {
              return e && e.tempFilePaths ? n && n(e.tempFilePaths) : i("相册选择失败，无路径返回")
            },
            fail: function(e) {
              return i(u(e, "无法从相册选择"))
            }
          })
        } (function(r) {
          var o = r.length,
          i = 0,
          u = [],
          n = function(e) {
            if (i++, e && e.data) {
              var n = {},
              t = "string" == typeof e.data && "[" == e.data.substr(0, 1) ? JSON.parse(e.data)[0] : e.data;
              n.path = t,
              n.bigpath = ~t.indexOf("_320.png") ? t.replace(/_320.png$/, "") : t,
              u.push(n)
            }
            return o <= i ? (f(), s && s(u)) : a(r[i])
          },
          a = function(e) {
            return l("上传中", !0),
            wx.uploadFile({
              url: c.upimg_url,
              filePath: e,
              name: "file",
              formData: {
                user: "test"
              },
              complete: function(e) {
                return 200 === e.statusCode ? n(e) : (console.log("上传接口出错", e), f(), p("第" + (curlen + 1) + "个资源上传失败，是否继续上传",
                function(e) {
                  return e.confirm ? (l("上传中"), n()) : s && s(u)
                }))
              }
            })
          };
          return a(r[i])
        },
        1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : 1)
      },
      _previewImage: function(e) {
        var n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : e[0];
        return wx.previewImage({
          current: n,
          urls: e,
          fail: function(e) {
            return console.log("预览失败", e),
            i("预览失败，请更新微信版本")
          }
        })
      },
      _ciipData: function(e, n) {
        return wx.setClipboardData({
          data: e,
          success: function(e) {
            return n && n()
          },
          fail: function(e) {
            return console.log("复制失败", e),
            i("复制失败，请更新微信版本")
          }
        })
      },
      _downloadFile: function(e, n) {
        return wx.downloadFile({
          url: e,
          success: function(e) {
            return e && e.tempFilePath ? n && n(e.tempFilePath) : i("下载失败，无路径返回")
          },
          fail: function(e) {
            var n = "";
            return console.log("_downloadFile", e),
            n = e && ~e.errMsg.indexOf("max file size") ? "文件过大，下载失败": u(e, "下载失败"),
            i(n)
          }
        })
      },
      _saveImage: h,
      _saveVideo: m,
      _allSave: function() {
        var r = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : [],
        n = arguments[1],
        e = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : 0,
        t = r.length,
        o = 0,
        i = 1 == e ? m: h,
        u = function() {
          return t <= ++o ? n && n() : s()
        },
        a = function() {
          return f(),
          p("第" + (o + 1) + "个资源下载失败，是否继续下载",
          function(e) {
            return e.confirm ? (l("保存中"), u()) : n && n()
          })
        },
        s = function() {
          var e, n, t = r[o].BigPicUrl || r[o].PicUrl;
          if (t) return e = t,
          n = function(e) {
            if (!e) return a();
            i(e,
            function(e) {
              return e ? u() : a()
            })
          },
          wx.downloadFile({
            url: e,
            complete: function(e) {
              return console.log("complete", e),
              e && 200 == e.statusCode && e.tempFilePath ? n && n(e.tempFilePath) : n && n()
            }
          })
        };
        return s()
      },
      BMap_getPostion: function(n) {
        return new bmap.BMapWX({
          ak: "EcnGLchYLhGiQFuGTEOohyqLIPjmpy3c"
        }).regeocoding({
          success: function(e) {
            return n && n(e)
          },
          fail: function(e) {
            return i("定位失败")
          }
        })
      },
      _makePhoneCall: function(e) {
        return wx.makePhoneCall({
          phoneNumber: e,
          fail: function(e) {
            console.log("拨打失败", e)
          }
        })
      },
      _payment: function() {
        var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
        n = arguments[1],
        t = arguments[2];
      
        return wx.requestPayment({
          timeStamp: e.timeStamp,
          nonceStr: e.nonceStr,
          package: e.package,
          signType: "MD5",
          paySign: e.paySign,
          success: function(e) {
            return n && n(e)
          },
          fail: function(e) {

            return e && e.errMsg && ~e.errMsg.indexOf("requestPayment:fail cancel") ? t && t(e)  : g("支付已取消", "none")

          }
          
        })
      },
      getusers: function(n) {
        return s("GetActivityMemberInfo", {},
        function(e) {
          return e.isSuccess ? n && n(e.result) : n && n()
        })
      }
    },
    o),
    n.exports = r
  },
  {
    "../config": 2,
    "./_ModalTip": 8,
    "./_errMsg": 9,
    "./_loading": 10,
    "./login": 12
  }],
  12 : [function(e, n, t) {
    var l = e("./session"),
    s = e("./_ModalTip"),
    r = e("./API"),
    f = e("../utils/index")._paramsToString,
    o = e("./_loading"),
    d = (o.showLoading, o.hideLoading),
    g = e("../config");
    function p(e) {
      if (e.header["Set-Cookie"]) {
        var t = l.get("session-cookie");
        t || (t = {}),
        e.header["Set-Cookie"].split("httponly,").forEach(function(e) {
          var n = e.split(";")[0].split("=");
          t[n[0]] = n[1]
        }),
        l.set("session-cookie", t)
      }
    }
    var i = function() {
      function e(e, n) {
        Error.call(this, n),
        this.type = e,
        this.message = n
      }
      return (e.prototype = new Error).constructor = e
    } (),
    h = function() {
      var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "当前页面接口出现错误，请退出后重新登录",
      n = 1 < arguments.length && void 0 !== arguments[1] ? arguments[1] : "",
      t = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
      r = getCurrentPages();
      if (d(), r) {
        var o = r.length - 1,
        i = r[o].options,
        u = r[o].route;
        g.abnor_path = "/" + u + f(i);
        var a = "?route=" + u;
        return n && (a += "&title=" + n),
        t && (a += "&ishide=true"),
        l.set("abnor_info", e),
        wx.redirectTo({
          url: "/pages/abnor/abnor" + a
        })
      }
      return s(e)
    },
    u = function() {
      var e = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : "",
      t = arguments[1],
      r = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
      o = "scope." + e;
      return s("请授权" + {
        userInfo: "用户信息",
        userLocation: "地理位置",
        address: "通讯地址",
        record: "录音功能",
        werun: "微信运动步数",
        invoiceTitle: "发票抬头",
        writePhotosAlbum: "保存到相册",
        camera: "摄像头"
      } [e],
      function n() {
        return wx.openSetting({
          success: function(e) {
            return e.authSetting[o] ? (console.log("授权成功"), t && t(!0)) : (console.log("重新授权", o), wx.showModal({
              title: "提示",
              confirmText: "重新授权",
              cancelText: "我知道了",
              confirmColor: "#4d8ac9",
              content: "取消授权，可能会使部分服务无法使用，或页面信息显示不完整。",
              showCancel: !r,
              success: function(e) {
                return r ? n() : e.confirm ? n() : e.cancel ? t && t(!0) : void 0
              },
              fail: function(e) {
                return console.log(e),
                s("授权弹窗失误")
              }
            }))
          }
        })
      })
    },
    a = function(n, t) {
      var r = 2 < arguments.length && void 0 !== arguments[2] && arguments[2],
      o = "scope." + n;
      return wx.getSetting({
        success: function(e) {
          return e.authSetting[o] ? t && t(!0) : (console.log("开始进行设备授权", e), wx.authorize({
            scope: o,
            success: function() {
              return t && t(!0)
            },
            fail: function(e) {
              return console.log("开始进行设备授权失败", e),
              u(n, t, r)
            }
          }))
        },
        fail: function(e) {
          console.log("获取用户的当前设置失败", e)
        }
      })
    },
    c = function(n) {
      var e = 1 < arguments.length && void 0 !== arguments[1] && arguments[1];
      return wx.getUserInfo({
        withCredentials: e,
        success: function(e) {
          return l.set("userInfo", e.userInfo),
          n && n({
            userInfo: e.userInfo,
            encryptedData: e.encryptedData || null,
            iv: e.iv || null
          })
        },
        fail: function(e) {
          return console.log("getAuthFail", e),
          n && n()
        }
      })
    },
    m = function(r) {
      return v(function(e) {
        if (e) {
          var t = l.get("userInfo");
          return wx.request({
            url: x("login"),
            data: e,
            method: "POST",
            success: function(e) {
              var n = e.data || {};
              return n.isSuccess ? (t = Object.assign(t, n.result), l.set("userInfo", t), r && r(n.result.sessionId)) : s(n.message || "登录接口失败")
            },
            fail: function(e) {
              return s("登录接口出错")
            }
          })
        }
        return r && r()
      })
    },
    v = function(t) {
      return wx.login({
        success: function(n) {
          return c(function(e) {
            return e ? t({
              code: n.code,
              userInfo: e.userInfo,
              encryptedData: e.encryptedData,
              iv: e.iv
            }) : t && t()
          },
          !0)
        },
        fail: function(e) {
          return t && t()
        }
      })
    },
    x = function(e) {
      return g.apihost + "/" + r[e]
    },
    w = function(e, u, a, s) {
      var n = !(4 < arguments.length && void 0 !== arguments[4]) || arguments[4],
      c = x(e),
      t = {};
      if (n) {
        var r = l.get("session-cookie");
        r && (t.Cookie = function(e) {
          var n = "";
          for (var t in e) n += t + "=" + e[t] + ";";
          return n
        } (r))
      }
      return wx.request({
        url: c,
        data: u,
        header: t,
        method: "POST",
        success: function(e) {
          if (200 === e.statusCode) return p(e),
          e.data.ErrorCode ? e.data.Message ? (d(), wx.showToast({
            title: e.data.Message,
            icon: "none",
            mask: !0
          }), s && s()) : h("状态200 接口出错: ") : a && a(e.data);
          if (401 === e.statusCode) {
            var n = getCurrentPages(),
            t = "";
            if (n.length) {
              var r = n.length - 1,
              o = n[r].options;
              t = "/" + n[r].route + f(o)
            }
            return t && (g.welcome_path = t),
            wx.reLaunch({
              url: "/pages/welcome/welcome"
            })
          }
          var i = "接口出错：url= " + c + "\n\n                    requedata= " + JSON.stringify(u) + "\n";
          return "string" != typeof e.data && (i += JSON.stringify(e.data)),
          h(i)
        },
        fail: function(e) {
          var n = "";
          if (~ (n = e && e.errMsg ? e.errMsg: JSON.stringify(e)).indexOf("abort")) return ! 1;
          var t = !!~n.indexOf("连接"),
          r = t ? n.replace("request:fail ", "") : "";
          return h("当前接口请求失败: url= " + c + "\n requedata=" + JSON.stringify(u) + "\n errMsg= " + n, r, t)
        },
        complete: function(e) {}
      })
    };
    n.exports = {
      RequestError: i,
      session: l,
      getUrl: x,
      _request: w,
      _JsonFailfn: h,
      initAuthLogin: function() {
        var n = 0 < arguments.length && void 0 !== arguments[0] ? arguments[0] : {},
        t = arguments[1];
        return wx.login({
          success: function(e) {
            return wx.request({
              url: x("login"),
              data: {
                provider: "weixinmapp",
                UserName: e.code,
                Meta: {
                  encrypteddata: n.encryptedData,
                  iv: n.iv
                }
              },
              method: "POST",
              success: function(n) {
                p(n),
                w("getToken", {
                  PreserveSession: !1
                },
                function(e) {
                  return t && t(n.data || {})
                })
              },
              fail: function(e) {
                var n = "";
                return n = e && e.errMsg ? ~errMsg.indexOf("not in domain") ? "公众号合法域名未配置": e.errMsg: "登录接口出错",
                s(n)
              }
            })
          },
          fail: function(e) {
            return s("微信登录失败")
          }
        })
      },
      GetSessionId: function(n) {
        var t = l.get("sessionId");
        return wx.checkSession({
          success: function(e) {
            return t ? n && n(t) : m(n)
          },
          fail: function(e) {
            return m(n)
          }
        })
      },
      auth_Fail: u,
      _AuthPress: a,
      GetUserInfo: function(n) {
        1 < arguments.length && void 0 !== arguments[1] && arguments[1];
        var t = l.get("userInfo");
        return wx.checkSession({
          success: function(e) {
            return t ? n && n(t) : c(function(e) {
              return n && n(e.userInfo)
            })
          },
          fail: function(e) {
            return l.clear("userInfo"),
            v(function(e) {
              return n && n(e.userInfo)
            })
          }
        })
      },
      _LoginPress: v
    }
  },
  {
    "../config": 2,
    "../utils/index": 5,
    "./API": 7,
    "./_ModalTip": 8,
    "./_loading": 10,
    "./session": 13
  }],
  13 : [function(e, n, t) {
    var r = {
      get: function(e) {
        return wx.getStorageSync(e) || null
      },
      set: function(e, n) {
        return wx.setStorageSync(e, n)
      },
      clear: function(e) {
        return wx.removeStorageSync(e)
      },
      info: function() {
        return wx.getStorageInfoSync()
      },
      allclear: function() {
        return wx.clearStorageSync()
      }
    };
    n.exports = r
  },
  {}]
},
{},
[1]);
//# sourceMappingURL=main.js.map
