let app = getApp()
let that;

Component({

    properties: {
        interval: { //自动切换时间间隔
            type: Number,
            value: 5000
        },
        duration: { //滑动动画时长
            type: Number,
            value: 500
        },
        autoplay: { //是否自动切换
            type: Boolean,
            value: false
        },
        indicatorDots: { //是否显示面板指示点
            type: Boolean,
            value: true
        },
        imgUrls: {
            type: Array,
            value: []
        }
    },

    created() {
        that = this;
    },
    attached() {
        that.curi = 0;

        return app.getSystemInfo(info => {
            that.screen_w = info.screenWidth;
        });
    },

    data: {
        swiperh: 1,
        isShow: false,
    },

    methods: {
        image_load: (event) => {
            let detail = event.detail || {};
            let detail_w = detail.width || 0;
            let detail_h = detail.height || 0;
            //let changed = {};

            detail_h = (that.screen_w*detail_h)/detail_w;

            /*that.curi++;
            if(that.curi >= that.data.imgUrls.length){
                changed['isShow'] = true;
            };*/

            if(that.data.swiperh < detail_h){
                //changed['swiperh'] = detail_h;
                return that.setData({
                    swiperh: detail_h
                });
            };

            //return that.setData(changed);
        }
    }
})
