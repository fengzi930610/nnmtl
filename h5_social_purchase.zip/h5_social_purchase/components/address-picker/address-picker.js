let that;
let app = getApp();

Component({
    properties: {
        show: {
            type: Boolean,
            value: false,
            observer(newVal, oldVal) {
                return that.setData({
                    pickstate: newVal
                });
            }
        },
        value: {
            type: Array,
            value: [],
        }
    },

    data: {
        region: [],
        ispopup: false,
        isbgshow: false,

        pickstate: false,
        province: [],
        city: [],
        area: [],
        picktxt: '',
        pickval: [0, 0, 0],
    },

    created() {
        that = this;
    },
    attached() {
        //console.log(that.data.value);
        return that._init();
    },

    methods: {
        _init() {
            //that.init_pickval = [0, 0, 0];
            return that.requsaddr((data) => {
                let pickval = that._initAreas(data);
                
                return that._addrssfn(pickval)
            });
        },
        _initAreas(data = [], seldata = that.data.value) {
            let pickval = [];

            if (data.length) data.map(function(el, ix) {
                if (el.name == seldata[0]) {

                    pickval.push(ix);

                    if (el.child.length) el.child.map(function(el1, ix1) {

                        if (el1.name == seldata[1]) {
                            pickval.push(ix1);

                            if (el1.child.length) el1.child.map(function(el2, ix2) {
                                if (el2.name == seldata[2]) pickval.push(ix2);
                            });
                        }

                    })
                }
            });

            if (pickval.length != 3) pickval = [0, 0, 0];

            return pickval;
        },

        //地址
        requsaddr(callback) {
            return wx.request({
                url: 'https://cdn.xiaojiankeji.com/JSON/other/AreaData_overseas.json',
                data: {},
                method: 'GET',
                success(res) {
                    that.addressList = res.data
                    return callback && callback(res.data)
                        //return that._addrssfn(pickval,res.data);
                },
                fail(err) {
                    return app._showModalTip('地址获取失败');
                }
            });
        },

        _addrssfn(pickval, addrss_data = that.addressList) {
            let province, city, area, len, citycur, areacur;

            len = addrss_data.length;
            province = addrss_data.map(function(el, ix) {
                if (ix == pickval[0]) {
                    citycur = ix;
                } else if (ix == (len - 1) && pickval[0] >= len) { //当滑动值大于总数
                    pickval[0] = len - 1;
                    citycur = len - 1;
                };
                return el.name;
            });

            len = addrss_data[citycur].child.length;
            city = addrss_data[citycur].child.map(function(el1, ix1) {
                if (ix1 == 0 && pickval[1] >= len) {
                    pickval[1] = 0;
                    areacur = 0;
                } else if (ix1 == pickval[1]) {
                    areacur = ix1;
                };
                return el1.name;
            });

            len = addrss_data[citycur].child[areacur].child.length;
            area = addrss_data[citycur].child[areacur].child.map(function(el2, ix2) {
                if (ix2 == 0 && pickval[2] >= len) pickval[2] = 0;
                return el2.name;
            });

            //console.log(province,city,area,pickval);
            return that.setData({
                province: province,
                city: city,
                area: area,
                pickval: pickval
            });
        },
        PickChange(event) {
            let pickval = event.detail.value;
            return that._addrssfn(pickval);
        },
        //地址选择
        /*bindRegionChange(e) {
          return that.setData({
            region: e.detail.value
          })
        },*/

        //取消
        pick_hide() {
            return this.triggerEvent('cancelEvent')
        },

        picker_confirm() {
            let pickval, datas;

            pickval = that.data.pickval;
            datas = that.data;
            //that.init_pickval = pickval;

            let region = [datas.province[pickval[0]], datas.city[pickval[1]], datas.area[pickval[2]]];

            return this.triggerEvent('confirmEvent', {
                region: region,
                pickstate: false,
            });
        },

        address_show() {
            return that.setData({
                pickstate: true
            });
        }
    }
})
