// 
let that;
Component({
  properties: {

    navcur: {          
      type: Number,  
      value: 0,
      observer(newVal, oldVal){
        return that.animalineFn(newVal)
      }
    },
    navlist:{          
      type: Array,  
      value: []    
    },
  },

  created(){
    that = this;
    that.animaline = wx.createAnimation({ 
        duration: 300,
        timingFunction: 'ease',
    });
  },
  attached(){
    return that.animalineFn(that.data.navcur)
  },

  data: {
    animaline:null
  },

  methods: {
    //动画执行
    animalineFn(cur){
      let latex = (100*cur+10)+'%';

      that.animaline.left(latex).step()
      return that.setData({
        navcur:cur,
        animaline: that.animaline.export()
      });

    },

    //列表点击
    navli_click(event){
      let navlist = that.data.navlist,
        cur = parseInt(event.currentTarget.dataset.index,10),
        curlist = navlist[cur] || {};

      if(cur==that.data.navcur) return false;

      that.animalineFn(cur);
      this.triggerEvent('clickEvent', {cur:cur,item:curlist})
    },
  }
})