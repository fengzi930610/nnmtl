// /components/tabBarfoot/tabbarfoot
let app = getApp()
Component({

    properties: {
        tabBarcur: {
            type: Number,
            value: 0
        },
    },

    data: {
        tabBarlist: [{
            "pagePath": "/pages/home/home",
            "iconPath": "../images/tabBar/tabBar1.png",
            "selectedIconPath": "../images/tabBar/tabBarred1.png",
            "text": "拼团活动"
        }, {
            "pagePath": "/pages/mycollage/mycollage",
            "iconPath": "../images/tabBar/tabBar4.png",
            "selectedIconPath": "../images/tabBar/tabBarred4.png",
            "text": "我的拼团"
        }]
    },

    methods: {
        pagepath(event) {
            let that = this,
                index = event.currentTarget.dataset.index,
                path = that.data.tabBarlist[index].pagePath,
                tabBarcur = that.data.tabBarcur;
            //console.log(tabBarcur,index,path);

            if (tabBarcur != index) {
                app._navto(3, path);
                that.setData({
                    tabBarcur: index
                });

            };
        }
    }
})
