/**
 * 小程序配置文件
 */

//域名
//https://cjypwapapi.ynbyweishang.com
// https://cjypwapapi.chujiayoupin.com || 正式
const apihost = 'https://cjypwapapi.ynbyweishang.com';	//接口域名
const imghost 		= "https://img.xsmore.com/cjyp";	//图片域名
const cdnhost 		= "https://cdn.xiaojiankeji.com";	//cdn资源域名
const upimg_url 	= "https://file.xsmore.com/api/image/upload?PlatForm=chujia&Path=Member"; //上传图片地址
const address_url 	= "https://cdn.xiaojiankeji.com/JSON/other/AreaData_overseas.json";	//自定义地址数据

const config = {
    appId: 'wx43123493d7bae872',
    appSecret: '8cbfa3d093d391947a38e0ad9f3c7918',
    appName: '初家友品拼团购',
    
    /* 只有320 || 640 */
    imgcut_640: '@!cut640',
    imgcut_320: '@!cut320',

    /* 错误跳转 */
    welcome_path: '',  
    abnor_path: '',
  default_path: '/pages/shoplist/shoplist',

    cancelList: ['收货人信息有误','商品数量或款式需调整','我不想买了','一直未发货','商品缺货','其他原因'],
    share_title: '我正在参加拼团，一起拼更便宜！',  //默认分享标题
    head_img: 'http://cdn.xsmore.com/Images/zmkm/pro_det_14.png', //默认头像
    port_max: 9, //头像最多显示个数

    apihost,
    imghost,
    cdnhost,
    upimg_url,
    address_url,

    StoreName: '初家友品-拼团活动',
    taburls: ['pages/welcome/welcome', 'pages/mycollage/mycollage', 'pages/home/home'], //底部tab页的切换 || 公共底部不需要

    orderStateList: ['','待付款','待发货','待发货','待收货','已完成','申请取消','','已取消','拼团中'],

};

module.exports = config;
